package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;



public class TotalScoreMapper implements RowMapper {
	@Override
	public Integer mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		
		return rs.getInt(3);
	}

}
