package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.model.testReport.TestReportBean;



public class TestReportMapper implements RowMapper {

	@Override
	public List<TestReportBean> mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		List<TestReportBean> list=new ArrayList<TestReportBean>();
		do{
			TestReportBean tb=new TestReportBean();
			tb.setCommitId(rs.getString(1));
			tb.setTestId(rs.getString(2));
			tb.setNoOfCorrect(rs.getInt(3));
			tb.setTotalScore(rs.getInt(4));
			tb.setRank(rs.getInt(5));
            list.add(tb);
		}while(rs.next());
		return list;
	}
	
	
}