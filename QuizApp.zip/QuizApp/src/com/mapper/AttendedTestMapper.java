package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

import com.model.attendedTest.AttendedTestBean;
import com.model.createdTest.CreatedTestBean;

public class AttendedTestMapper implements RowMapper {

	@Override
	public AttendedTestBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Map<String, String> map = new HashMap<String, String>();
		AttendedTestBean bean = new AttendedTestBean();
		//CreatedTestBean cbean = new CreatedTestBean();
	do{
		bean.setCommitId(rs.getString("commitId"));
		
			System.out.println("INSIDE*"+rs.getString(1)+rs.getString("testId")+ rs.getString("timeOFATTEMPT"));
			//cbean.setTestId(rs.getString("testId"));
			map.put(rs.getString("testId"), rs.getString("timeOFATTEMPT"));
		}while(rs.next());
		bean.setTests(map);
		return bean;
	}
	
}
