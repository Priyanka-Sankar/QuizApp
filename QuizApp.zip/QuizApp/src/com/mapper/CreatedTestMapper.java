package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.createdTest.CreatedTestBean;

public class CreatedTestMapper implements RowMapper{

	@Override
	public CreatedTestBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		CreatedTestBean bean = new CreatedTestBean();
		if(rs != null)
		{
			bean.setTestId(rs.getString("testId"));
			bean.setTestName(rs.getString("testName"));
			bean.setCutoff(rs.getInt("cutoff"));
			bean.setDuration(rs.getInt("duration"));
			bean.setStartTime(rs.getString("startTime"));
			bean.setExpiryTime(rs.getString("endTime"));
			bean.setNoQues(rs.getInt("noQues"));
			bean.setShowMark(rs.getString("showMark"));
			bean.setShuffle(rs.getString("shuffle"));
		}
		return bean;
	}

}
