package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

import com.model.library.LibraryBean;
import com.model.question.QuestionBean;

public class LibraryMapper implements RowMapper{

	@Override
	public List<LibraryBean> mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		List<QuestionBean> qBean = new ArrayList<QuestionBean>();
		Map<String, List<QuestionBean>> map = new HashMap<String, List<QuestionBean>>(); 
		
		List<LibraryBean> lBean=new ArrayList<LibraryBean>();
		do{
		if(map.containsKey(rs.getString("category")+"-"+rs.getString("tag")))
		{
			List<QuestionBean> list = map.get(rs.getString("category")+"-"+rs.getString("tag"));
			QuestionBean bean = new QuestionBean();
			bean.setQuesId(rs.getString("quesId"));
			list.add(bean);
			map.put(rs.getString("category")+"-"+rs.getString("tag"),list);
		}
		else
		{
			List<QuestionBean> list = new ArrayList<QuestionBean>();
			QuestionBean bean = new QuestionBean();
			bean.setQuesId(rs.getString("quesId"));
			list.add(bean);
			map.put(rs.getString("category")+"-"+rs.getString("tag"), list);
		}
			
		}while(rs.next());
		for(Map.Entry<String, List<QuestionBean>> e : map.entrySet())
		{
			String[] cat_tag = e.getKey().split("-");
			LibraryBean lb=new LibraryBean();
			lb.setCategory(cat_tag[0]);
			lb.setTag(cat_tag[1]);
			lb.setQuestions(e.getValue());
			lBean.add(lb);
		}
		return lBean;
	}
	

}
