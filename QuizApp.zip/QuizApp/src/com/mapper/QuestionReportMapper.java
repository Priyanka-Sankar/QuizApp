package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.model.questionReport.QuestionReportBean;

public class QuestionReportMapper implements RowMapper {

	@Override
	public List<QuestionReportBean> mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		List<QuestionReportBean> list=new ArrayList<QuestionReportBean>();
		do{
			System.out.println("ins mapper");
			QuestionReportBean qb=new QuestionReportBean();
			qb.setCommitId(rs.getString(1));
			qb.setTestId(rs.getString(2));
			qb.setQuesId(rs.getString(3));
			String ans=rs.getString(4);
			String[] answers=ans.split("\\$");
			Integer[] array= new Integer[answers.length];
			for(int i=0;i<answers.length;i++)
			{
				array[i]=Integer.parseInt(answers[i]);
			}
			System.out.println(array.length);
			List<Integer> s2l = Arrays.asList(array);
            qb.setChosenAns(s2l);
            qb.setScore(rs.getInt(5));
            list.add(qb);
		}while(rs.next());
		return list;
	}
}
