package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.model.question.QuestionBean;

public class QuestionMapper implements RowMapper<QuestionBean>{


@Override
public QuestionBean mapRow(ResultSet rs, int rowNum) throws SQLException {
	// TODO Auto-generated method stub
	
	List<Integer> ansList = new ArrayList<Integer>();
	QuestionBean qbean=new QuestionBean();
	try {
		qbean.setQuesId(rs.getString(1));
		qbean.setQuesDesc(rs.getString(2));
		
		String[] optArray=rs.getString(3).split("\\$");
		qbean.setOptions(Arrays.asList(optArray));
		System.out.println(rs.getString(4));
		String[] ansArray=rs.getString(4).split("\\$");
		for(String ans:ansArray)
		{
			//System.out.println(ansArray[0]);
			ansList.add(new Integer(ans));
		}
		qbean.setAnswers(ansList);
		qbean.setMark(rs.getInt(5));
		qbean.setImage(rs.getString(6));
		//qb.setAnswers(answers);
		qbean.setDifficulty(rs.getString(7));
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return qbean;
}

/*public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
    Student student = new Student();
    student.setId(rs.getInt("id"));
    student.setName(rs.getString("name"));
   
    return student;
 }*/

}
