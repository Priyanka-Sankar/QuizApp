package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.model.user.UserBean;

public class UserMapper implements RowMapper{
	public UserBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		UserBean User = new UserBean();
		if(rs != null)
		{	
			User.setCommitId(rs.getString(1));
			User.setPassword(rs.getString(2));
			User.setEmailId(rs.getString(3));
		}
		else
			return null;
		return User;
	}
}
