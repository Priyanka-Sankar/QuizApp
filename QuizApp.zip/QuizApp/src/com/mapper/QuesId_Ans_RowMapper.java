package com.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

public class QuesId_Ans_RowMapper implements RowMapper {

	@Override
	public String mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		
		return rs.getString(1);
	}


}
