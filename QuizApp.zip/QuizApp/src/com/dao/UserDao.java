package com.dao;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.UserMapper;
import com.model.user.UserBean;

@Component
public class UserDao extends JdbcDaoSupport{
	String table = "QuizAppUser";
	@Autowired
	public UserDao(DataSource dataSource)
	{
		setDataSource(dataSource);
	}
	public UserBean createUser(UserBean User) throws Exception
	{
		int num=0;
		try{
			num = getJdbcTemplate().update("INSERT INTO "+table+" VALUES(?,?,?)",new Object[]{ User.getCommitId(), User.getPassword(), User.getEmailId()},new int[]{Types.INTEGER, Types.VARCHAR, Types.VARCHAR});	
		}
		catch(Throwable e){
			throw new Exception(e);
		}
		return  (num == 1 ? User : null);
		
	}
	public int getUser(String commitId, String password) throws Exception
	{
		List<UserBean> User = null;
		try{
		User =  getJdbcTemplate().query("SELECT * FROM "+table+" WHERE commitId=? AND password = ?",new Object[]{commitId, password}, new int[]{Types.VARCHAR, Types.VARCHAR},new UserMapper());
		if(User.isEmpty())
		{
			throw new Exception("No user found");
		}
		return 1;
		}
		catch(Throwable e)
		{
			throw new Exception(e); 
		}
		
		
	}
}
