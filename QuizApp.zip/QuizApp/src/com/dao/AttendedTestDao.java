package com.dao;

import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.AttendedTestMapper;
import com.model.attendedTest.AttendedTestBean;
import com.model.createdTest.CreatedTestBean;

@Component
public class AttendedTestDao extends JdbcDaoSupport{

		String table = "QUIZAPP_TESTSTAKEN";
		@Autowired
		CreatedTestDao ctestDao;
		@Autowired
		public AttendedTestDao(DataSource dataSource)
		{
			setDataSource(dataSource);
		}
		
		public AttendedTestBean createAttendTest(AttendedTestBean testBean) throws Exception
		{
			int num = 0;
			String commitId = testBean.getCommitId();
			System.out.println("inside a test");
			try{
			for(Map.Entry<String, String> map : testBean.getTests().entrySet())
			{
				String testId = map.getKey();
				String time = map.getValue();
				System.out.println(testId+"  "+time);
				num = getJdbcTemplate().update("INSERT INTO "+table+" VALUES (?, ?, ?)", new Object[]{commitId, testId, time}, new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
				
			}
			return testBean;
			}
			catch(Exception e){
				e.printStackTrace();
				throw new Exception(e);
			}
		}
		public AttendedTestBean updateAttendTest(String id, AttendedTestBean bean){
			//getJdbcTemplate().update("UPDATE "+table+" SET column = ? WHERE ", new Object[]{}, new int[]{});
			return new AttendedTestBean();
		}
		
		public AttendedTestBean getAttendTestById(String commitId) throws Exception
		{
			AttendedTestBean bean;
			try{
			 bean = getJdbcTemplate().queryForObject("SELECT * FROM "+table+" WHERE commitId = ?",new Object[]{commitId}, new int[]{Types.VARCHAR}, new AttendedTestMapper());
			if(bean != null){
				return bean;
			}
			}
			catch(Throwable e){
				bean = null;
				throw new Exception(e.getMessage());
			}
			return bean;
		}
		
		public int deleteAttendedTestByCommitId(String commitId)
		{
			try{
				AttendedTestBean bean =  getJdbcTemplate().queryForObject("SELECT * FROM "+table+" WHERE commitId=?",new Object[]{commitId}, new int[]{Types.VARCHAR},new AttendedTestMapper());
				if(bean == null)
					throw new Exception("No such data");
				return getJdbcTemplate().update("DELETE FROM "+table+" WHERE commitId=?", new Object[]{commitId}, new int[]{Types.INTEGER});
			}
			catch(Throwable e)
			{
				//throw new Exception(e);
			}
			return 0;
		}
		
		public int deleteAttendedTestByTestId(String testId)
		{
			try{
				AttendedTestBean bean =  getJdbcTemplate().queryForObject("SELECT * FROM "+table+" WHERE testId=?",new Object[]{testId}, new int[]{Types.VARCHAR},new AttendedTestMapper());
				if(bean == null)
					throw new Exception("No such data");
				return getJdbcTemplate().update("DELETE FROM "+table+" WHERE TESTId=?", new Object[]{testId}, new int[]{Types.VARCHAR});
			}
			catch(Throwable e)
			{
				//throw new Exception(e);
			}
			return 0;
		}
}
