package com.dao;

import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.QuestionMapper;
import com.model.question.QuestionBean;

@Component
public class QuestionDao extends JdbcDaoSupport {

                String table="QuizApp_Question";
                @Autowired
                public QuestionDao(DataSource dataSource)
                {
                                setDataSource(dataSource);
                }
                /*
                * TO APPEND ; in the Qns and answers
                */
                private String appendString(List<String> options) {
                                // TODO Auto-generated method stub
                                String s1 ="";
                                int i;
                                //String s2=options.get(0);
                                for(i=0;i<options.size()-1;i++)
                                {
                                                s1+=options.get(i);
                                                s1+="$";
                                }
                                s1+=options.get(i);

                                return s1;
                }
                
                private String appendInt(List<Integer> options) {
                                // TODO Auto-generated method stub
                                String s1 = "";
                                //String s2=options.get(0);
                                int i;
                                for(i=0;i<options.size()-1;i++)
                                {
                                                s1+=options.get(i);
                                                s1+="$";
                                }
                                s1+=options.get(i);

                                return s1;
                }
                
                public QuestionBean getQuestion(String quesId) {
                                // TODO Auto-generated method stub
                                
                                QuestionBean qb = null;
                                
                                //Object []params={quesId};
                String sql="select * from "+table+" where quesId=?";
                qb= getJdbcTemplate().queryForObject(sql,new Object[]{quesId},new int[]{Types.VARCHAR},new QuestionMapper());
                                return qb;
                }
                
                
                public int createQuestion(QuestionBean qBean)
                {
                                int res = 0;
                                String sql="insert into "+table+" values(?,?,?,?,?,?,?)";
                                String opt=appendString(qBean.getOptions());
                                String ans=appendInt(qBean.getAnswers());
                                System.out.println(opt+ans);
                                int [] types={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.INTEGER, Types.CLOB, Types.VARCHAR};
                                
                                Object[] params={qBean.getQuesId(),qBean.getQuesDesc(),opt,ans,qBean.getMark(), qBean.getImage(), qBean.getDifficulty()};
                                System.out.println(sql);
                                res=getJdbcTemplate().update(sql,params,types);
                                
                                return res;
                                
                }
                
                public int updateQuestions(QuestionBean qBean, String updateField)    
                {
                                int num = 0;
                                switch(updateField)
                                {
                                case "description":{
                                                num = getJdbcTemplate().update("UPDATE "+table+" SET quesDesc = '"+qBean.getQuesDesc()+"' WHERE quesId = '"+qBean.getQuesId()+"'");
                                                break;
                                }
                                case "options" :{
                                                String opt = appendString(qBean.getOptions());
                                                num = getJdbcTemplate().update("UPDATE "+table+" SET options = '"+opt+"' WHERE quesId = '"+qBean.getQuesId()+"'");
                                                break;
                                }
                                case "answers" : {
                                                String ans = appendInt(qBean.getAnswers());
                                                num = getJdbcTemplate().update("UPDATE "+table+" SET answers = '"+ans+"' WHERE quesId = '"+qBean.getQuesId()+"'");
                                                break;
                                }
                                case "mark" :{
                                                num = getJdbcTemplate().update("UPDATE "+table+" SET mark = "+qBean.getMark()+" WHERE quesId = '"+qBean.getQuesId()+"'");
                                                break;
                                }
                                case "image" : {
                                                num = getJdbcTemplate().update("UPDATE "+table+" SET image = ? WHERE quesId = ?",new Object[]{qBean.getImage(),qBean.getQuesId()},new int[]{Types.CLOB,Types.VARCHAR});
                                                break;
                                }
                                case "difficulty" :{
                                                num = getJdbcTemplate().update("UPDATE "+table+" SET difficulty = '"+qBean.getDifficulty()+"' WHERE quesId = '"+qBean.getQuesId()+"'");
                                                break;
                                }
                                default:
                                {
                                	return -1;
                                }
                                }
                                return num;
                }
                
                public int deleteQuestion(String qid)throws Exception
                {
                                try{
                                String sql="delete from "+table+" where quesid=?";
                                Object[] param={qid};
                                int [] types={Types.VARCHAR};
                                
                                int res=getJdbcTemplate().update(sql,param,types);
                                return res;
                                
                }
                                catch(Throwable e)
                                {
                                                throw new Exception(e.getMessage());
                                }
                }
                

                
}


