package com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.support.JdbcDaoSupport;





import com.mapper.QuesId_Ans_RowMapper;
import com.mapper.QuesId_Score_RowMapper;
import com.mapper.QuestionReportMapper;
import com.model.question.QuestionBean;
import com.model.questionReport.QuestionReportBean;

@Component
public class QuestionReportDao extends JdbcDaoSupport {
	@Autowired
	public QuestionReportDao(DataSource datasource) {
		// TODO Auto-generated constructor stub
		System.out.print("inside dao cons1");
		setDataSource(datasource);
		
	}
	@Autowired
	LibraryDao lDao;
	
	public int insertQReport(QuestionReportBean qRBean){
		

//commitId varchar(25),testId varchar(25),quesId  varchar(25) ,chosenAns varchar(10),score int
		List<Integer> chosenAns=qRBean.getChosenAns();
		String chosenAnswer="";
		int i=0;
		for(i=0;i<chosenAns.size()-1;i++)
		{
			chosenAnswer+=chosenAns.get(i)+"$";
		}
		chosenAnswer+=chosenAns.get(i);
	       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
	       /*derby*/String query="INSERT INTO QuizApp_QuestionReport VALUES('"+qRBean.getCommitId()+"','"+qRBean.getTestId()+"','"+qRBean.getQuesId()+"','"+chosenAnswer+"',"+compareAnswers(qRBean.getQuesId(),chosenAnswer)+")";
	        int r=getJdbcTemplate().update(query);
	        if(r==1)
	        	return 1;
	        else
	        	return 0;
		    
	} 
	public String getAnswers(String quesId)
	{
		String query="select answers from QUIZAPP_QUESTION where quesid='"+quesId+"'";
		String answers=getJdbcTemplate().queryForObject(query,new QuesId_Ans_RowMapper());
		
		
		return answers;
	}
	public int getIScore(String quesId)
	{
		String query="select mark from QUIZAPP_QUESTION where quesid='"+quesId+"'";
		int score=getJdbcTemplate().queryForObject(query,new QuesId_Score_RowMapper());
		System.out.println(score+"iscore");
		return score;
	}
	public List<QuestionReportBean> getReport()
	{
		String query="select * from QUIZAPP_QUESTIONReport";
		List<QuestionReportBean> list=getJdbcTemplate().query(query,new QuestionReportMapper());
		return list;
	
	}
	public List<QuestionReportBean> getCTReport(QuestionReportBean qrb)
	{
		String query="select * from QUIZAPP_QUESTIONReport  where commitId='"+qrb.getCommitId()+"' and testId='"+qrb.getTestId()+"'";
		List<QuestionReportBean> list=getJdbcTemplate().query(query,new QuestionReportMapper());
		return list;
	
	}
	public List<QuestionReportBean> getCTQReport(QuestionReportBean qrb)
	{
		String query="select * from QUIZAPP_QUESTIONReport  where commitId='"+qrb.getCommitId()+"' and testId='"+qrb.getTestId()+"'and quesId='"+qrb.getQuesId()+"'";
		List<QuestionReportBean> list;
		try{
		list=getJdbcTemplate().query(query,new QuestionReportMapper());
		
		}
		catch(Exception e)
		{
			return null;
		}
		return list;
	
	}
	public List<QuestionReportBean> getReportCommitId(String commitId)
	{
		String query="select * from QUIZAPP_QUESTIONReport where commitId='"+commitId+"'";
		List<QuestionReportBean> list=getJdbcTemplate().queryForObject(query,new QuestionReportMapper());
		return list;
	
	}
	public List<QuestionReportBean> getReportTestId(String testId)
	{
		String query="select * from QUIZAPP_QUESTIONReport where testId='"+testId+"'";
		List<QuestionReportBean> list=getJdbcTemplate().query(query,new  QuestionReportMapper());
		return list;
	
	}
	
	public List<QuestionReportBean> getReportQuesId(String quesId)
	{
		String query="select * from QUIZAPP_QUESTIONReport where quesId='"+quesId+"'";
		List<QuestionReportBean> list=getJdbcTemplate().query(query,new  QuestionReportMapper());
		return list;
	
	}
	public int compareAnswers(String quesId,String chosenAns)
	{
		System.out.println(chosenAns+getAnswers(quesId));
		if(chosenAns.contentEquals(getAnswers(quesId)))
		{
			System.out.println("equal");
			return getIScore(quesId);
		}
		else
		{
			return 0;
		}
		
	}
	public int update(String whatToUpdate,QuestionReportBean qrb)
	{
		switch(whatToUpdate)
		{
		case "score":
		{
			String query="update QuizApp_QuestionReport set score="+qrb.getScore()+" where commitId='"+qrb.getCommitId()+"' and testId='"+qrb.getTestId()+"' and quesId='"+qrb.getQuesId()+"'";
	        int r=getJdbcTemplate().update(query);
	        if(r==1)
	        	return 1;
	        else
	        	return 0;
		}
		case "answer":
		{
			List<Integer> chosenAns=qrb.getChosenAns();
			String chosenAnswer="";
			for(int option:chosenAns)
			{
				chosenAnswer+=option+"$";
			}
			String query="update QuizApp_QuestionReport set chosenAns='"+chosenAnswer+"' where commitId='"+qrb.getCommitId()+"' and testId='"+qrb.getTestId()+"' and quesId='"+qrb.getQuesId()+"'";
	        int r=getJdbcTemplate().update(query);
	        if(r==1)
	        	return 1;
	        else
	        	return 0;
		}
		}
		return -1;
		
	}
	public int delete(QuestionReportBean qrb)
	{
		String query="delete from QuizApp_QuestionReport where commitId='"+qrb.getCommitId()+"' and testId='"+qrb.getTestId()+"' and quesId='"+qrb.getQuesId()+"'";
        int r=getJdbcTemplate().update(query);
        if(r==1)
        	return 1;
        else
        	return 0;
	}
	public int delete(String commitId)
	{
		String query="delete from QuizApp_QuestionReport where commitId='"+commitId+"'";
        int r=getJdbcTemplate().update(query);
        if(r!=0)
        	return 1;
        else
        	return 0;
	}
	public int delete_testid(String testId)
	{
		String query="delete from QuizApp_QuestionReport where testId='"+testId+"'";
        int r=getJdbcTemplate().update(query);
        if(r!=0)
        	return 1;
        else
        	return 0;
	}
	public Map<String,Integer> getCatScore(String commitId)
	{
		Map<String,Integer> catScore=new HashMap<String,Integer>();
		List<QuestionReportBean> qRList=getReportCommitId(commitId);
		for(QuestionReportBean bean:qRList)
		{
			String category=lDao.getCategory(bean.getQuesId());
			if(!catScore.containsKey(category))
			{
				catScore.put(category, bean.getScore());
			}
			else
			{
				int score=catScore.get(category);
				catScore.remove(category);
				catScore.put(category,score+bean.getScore());
			}
			
		}
		return catScore;
	}
	public Map<String,Integer> getTScore(String commitId)
	{
		Map<String,Integer> catScore=new HashMap<String,Integer>();
		List<QuestionReportBean> qRList=getReportCommitId(commitId);
		for(QuestionReportBean bean:qRList)
		{
			String category=lDao.getCategory(bean.getQuesId());
			if(!catScore.containsKey(category))
			{
				catScore.put(category, bean.getScore());
			}
			else
			{
				int score=catScore.get(category);
				catScore.remove(category);
				catScore.put(category,score+bean.getScore());
			}
			
		}
		return catScore;
	}
	
}
