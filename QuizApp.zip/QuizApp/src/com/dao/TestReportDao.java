package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.QuestionReportMapper;
import com.mapper.TestReportMapper;
import com.mapper.TotalScoreMapper;
import com.model.questionReport.QuestionReportBean;
import com.model.testReport.TestReportBean;

@Component
public class TestReportDao extends JdbcDaoSupport{
	@Autowired
	QuestionReportDao qrd;
	@Autowired
	public TestReportDao(DataSource datasource)  {
		// TODO Auto-generated constructor stub
		System.out.print("inside dao cons1");
		setDataSource(datasource);
		
	}
	public int insertTReport(TestReportBean tRBean){
		

		//commitId varchar(25),testId varchar(25),noOfCorrect int,totalScore int,rank int
				
			      String query="INSERT INTO QuizApp_TestReport VALUES('"+tRBean.getCommitId()+"','"+tRBean.getTestId()+"',"+tRBean.getNoOfCorrect()+","+tRBean.getTotalScore()+","+tRBean.getRank()+")";
			        int r=getJdbcTemplate().update(query);
			        if(r==1)
			        	return 1;
			        else
			        	return 0;
				    
			} 
	public int calcTotalScore(TestReportBean tRBean)
	{
		String query="select commitId,testId,sum(score) from QuizApp_QuestionReport where commitId='"+tRBean.getCommitId()+"' and testId='"+tRBean.getTestId()+"' group by commitId,testId";
        int total=getJdbcTemplate().queryForObject(query,new TotalScoreMapper());
        
        	return total;
	}
	public int calcNoOfCorrect(TestReportBean tRBean)
	{
		int  noOfCorrect=0;
		String query="select * from QuizApp_QuestionReport where commitId='"+tRBean.getCommitId()+"' and testId='"+tRBean.getTestId()+"'";
        List<QuestionReportBean> list1=getJdbcTemplate().queryForObject(query,new QuestionReportMapper());
        for(int i=0;i<list1.size();i++)
        {
        	QuestionReportBean qrb=list1.get(i);
        	noOfCorrect+=checkCorrect(qrb.getQuesId(),qrb.getScore());
        }
        System.out.println("after noc"+noOfCorrect);
        	return noOfCorrect;
	}
	public int checkCorrect(String quesId,int score)
	{
	   
		if(qrd.getIScore(quesId)==score)
		{
			return 1;
		}
		return  0;
	}
	public List<TestReportBean> getReport()
	{
		String query="select * from QUIZAPP_TestReport";
		List<TestReportBean> list=getJdbcTemplate().queryForObject(query,new TestReportMapper());
		return list;
	
	}
	public List<TestReportBean> getReport(String commitId)
	{
		String query="select * from QUIZAPP_TestReport where commitid='"+commitId+"' order by totalScore desc";
		List<TestReportBean> list=getJdbcTemplate().queryForObject(query,new TestReportMapper());
		return list;
	
	}
	public List<TestReportBean> getReportTestId(String testId)
	{
		String query="select * from QUIZAPP_TestReport where testId='"+testId+"'";
		List<TestReportBean> list=getJdbcTemplate().queryForObject(query,new TestReportMapper());
		return list;
	
	}
	public  int getaTest(String testId,String commitId)

    {
System.out.println(commitId+"      gggg  "+testId);
            String query="select * from QUIZAPP_TestReport where testId='"+testId+"' and commitId='"+commitId+"'";

            try{

            List<TestReportBean> list=getJdbcTemplate().queryForObject(query,new TestReportMapper());

            if(list.size()>0)

                    return -1;

            else 

                    

                            return 1;

            }

            catch(EmptyResultDataAccessException e)

            {

                    return 1;

            }

            

    }
	public  List<TestReportBean> getRank(String testId,String commitId)
	{
		String query="select * from QUIZAPP_TestReport where testId='"+testId+"' order by totalScore desc,commitId asc";
		List<TestReportBean> list=getJdbcTemplate().queryForObject(query,new TestReportMapper());
				return list;
	}
	public List<TestReportBean> getReport(TestReportBean trb)
	{
		String query="select * from QUIZAPP_TestReport where commitid='"+trb.getCommitId()+"' and testId='"+trb.getTestId()+"'";
		List<TestReportBean> list=getJdbcTemplate().query(query,new TestReportMapper());
		return list;
	
	}
	public int delete(TestReportBean trb)
	{
		String query="delete from QuizApp_TestReport where commitId='"+trb.getCommitId()+"' and testId='"+trb.getTestId()+"'";
        int r=getJdbcTemplate().update(query);
        if(r==1)
        	return 1;
        else
        	return 0;
	}
	public int delete(String commitId)
	{
		String query="delete from QuizApp_TestReport where commitId='"+commitId+"'";
        int r=getJdbcTemplate().update(query);
        if(r==1)
        	return 1;
        else
        	return 0;
	}
	public int delete_testid(String testId)
	{
		String query="delete from QuizApp_TestReport where testId='"+testId+"'";
        int r=getJdbcTemplate().update(query);
        if(r==1)
        	return 1;
        else
        	return 0;
	}
	public Map<String,Integer> getTScore()
	{
		Map<String,Integer> catScore=new HashMap<String,Integer>();
		List<TestReportBean> tRList=getReport();
		for(TestReportBean bean:tRList)
		{
			String cid=bean.getCommitId();
			if(!catScore.containsKey(cid))
			{
				catScore.put(cid, bean.getTotalScore());
			}
			else
			{
				int score=catScore.get(cid);
				catScore.remove(cid);
				catScore.put(cid,score+bean.getTotalScore());
			}
			
		}
		return catScore;
	}
}
