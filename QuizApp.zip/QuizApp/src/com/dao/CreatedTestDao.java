package com.dao;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.CreatedTestMapper;
import com.model.createdTest.CreatedTestBean;
import com.model.question.QuestionBean;

@Component
public class CreatedTestDao extends JdbcDaoSupport{

	String testTable = "QuizApp_Quiz";
	String testQuestion = "QuizApp_QuizQuestions";
	String testStatus = "QuizApp_TestStatus";
	String testTaken = "QuizApp_TestsTaken";
	@Autowired
	QuestionDao quesDao;
	@Autowired
	public CreatedTestDao(DataSource dataSource)
	{
		setDataSource(dataSource);
	}
	

	public CreatedTestBean createTest(CreatedTestBean testBean) throws Exception
	{
		int num = 0;
		
		try{
		System.out.println();
		//insert into testTable
		num = getJdbcTemplate().update("INSERT INTO "+testTable+" VALUES(?, ?, ?, ?, ?, ?, ?, ?, ? )", new Object[]{testBean.getTestId(), testBean.getTestName(), testBean.getCutoff(), testBean.getDuration(), testBean.getStartTime(), testBean.getExpiryTime(), testBean.getNoQues(), testBean.getShowMark(), testBean.getShuffle()});
		System.out.println("hii"+num);
		
		//insert into testQuestions
		for(QuestionBean bean : testBean.getQuestions())
			num = getJdbcTemplate().update("INSERT INTO "+testQuestion+" VALUES(?, ?)", new Object[]{testBean.getTestId(), bean.getQuesId()}, new int[]{Types.VARCHAR, Types.VARCHAR});
	
		//insert into testStatus
			num=getJdbcTemplate().update("INSERT INTO "+testStatus+" VALUES(?, ?, ?)", new Object[]{testBean.getCommitId(), testBean.getTestId(), testBean.getStatus()}, new int[]{Types.VARCHAR, Types.VARCHAR,Types.VARCHAR});
			System.out.println("test status"+num);
		//update NoofQuestions
		int noQues = getNoOfQues(testBean.getTestId());
		
			updateNoQues(testBean.getTestId(), noQues);
		}
		catch(Throwable e)
		{	e.printStackTrace();
			throw new Exception(e.getCause());
		}
		return testBean;
	}
	public List<CreatedTestBean> getTestByCommitId(String commitId) throws Exception {

		List<CreatedTestBean> testList = new ArrayList<CreatedTestBean>();
		
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList("SELECT * from "+testStatus+" WHERE commitId = '"+commitId+"'");
		try{
			System.out.println("ins try");
		for(Map row : rows)
		{
			System.out.println("ins for");
			List<QuestionBean> qbList=new ArrayList<QuestionBean>();
			CreatedTestBean testBean = new CreatedTestBean();
			//get testdetails and quesDetails
			testBean = getTestQuestionsByTestId((String)row.get("testId"));
			testBean.setCommitId(commitId);
			testBean.setStatus((String)row.get("status"));
			
			testList.add(testBean);
		}
		}
		catch(Throwable e)
		{
			e.printStackTrace();
			throw new Exception(e.getCause());
		}
		return testList;
	}
	
	public List<CreatedTestBean> getTest(String commitId) throws Exception {

        List<CreatedTestBean> testList = new ArrayList<CreatedTestBean>();
        
        List<Map<String, Object>> rows = getJdbcTemplate().queryForList("SELECT * from "+testStatus+" where testId NOT IN (SELECT testId FROM "+testTaken+" WHERE commitId = '"+commitId+"')");
        try{
                        System.out.println("ins try");
        for(Map row : rows)
        {
                        System.out.println("ins for");
                        List<QuestionBean> qbList=new ArrayList<QuestionBean>();
                        CreatedTestBean testBean = new CreatedTestBean();
                        //get testdetails and quesDetails
                        testBean = getTestQuestionsByTestId((String)row.get("testId"));
                        testBean.setCommitId((String)row.get("commitId"));
                        testBean.setStatus((String)row.get("status"));
                        
                        testList.add(testBean);
        }
        }
        catch(Throwable e)
        {
                        e.printStackTrace();
                        throw new Exception(e.getCause());
        }
        return testList;
}

public CreatedTestBean getTestQuestionsByTestId(String testId) {
                    // TODO Auto-generated method stub
                    
                    CreatedTestBean bean = getTestDetailsById(testId);
                    bean.setQuestions(getQuestionsByTestId(bean.getTestId()));
                    for(QuestionBean qb :bean.getQuestions())
                    {
                                    System.out.println("ins for2");

                                    System.out.println(qb.getQuesId());
                                    
                    }

                    return bean;
    }
    
    public CreatedTestBean getTestDetailsById(String testId)
    {
                    System.out.println("tesTTTT"+testId);
                    CreatedTestBean bean = getJdbcTemplate().queryForObject("SELECT * FROM "+testTable+" natural join "+testStatus+" WHERE testId = ?", new Object[]{testId}, new int[]{Types.VARCHAR}, new CreatedTestMapper());
                    return bean;
    }

    

    
    
    public List<QuestionBean> getQuestionsByTestId(String testId)
    {
                    List<QuestionBean> quesList = new ArrayList<QuestionBean>();
                    List<Map<String, Object>> rows  = getJdbcTemplate().queryForList("SELECT quesId from "+testQuestion+" WHERE testId = ?", new Object[]{testId}, new int[]{Types.VARCHAR}); 
                    for(Map row : rows)
                    {
                                    System.out.println((String)row.get("quesId"));
                                    QuestionBean qBean = quesDao.getQuestion((String)row.get("quesId"));
                                    quesList.add(qBean);
                    }
                    return quesList;
    }
    

	
	public int updateTest(CreatedTestBean testBean, String updateField) throws Exception 
	{
		System.out.println("Update "+updateField);
		int num = 0;
		try{
			switch(updateField)
			{
			case "testName" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET testName = ? WHERE testId = ?", new  Object[]{testBean.getTestName(), testBean.getTestId()}, new int[]{Types.VARCHAR, Types.VARCHAR});
				break;
			}
			case "cutoff" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET cutoff = ? WHERE testId = ?", new  Object[]{testBean.getCutoff(), testBean.getTestId()}, new int[]{Types.INTEGER, Types.VARCHAR});
				break;
			}
			case "duration" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET duration = ? WHERE testId = ?", new  Object[]{testBean.getDuration(), testBean.getTestId()}, new int[]{Types.INTEGER, Types.VARCHAR});
				break;
			}
			
			case "startTime" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET startTime = ? WHERE testId = ?", new  Object[]{testBean.getStartTime(), testBean.getTestId()}, new int[]{Types.VARCHAR, Types.VARCHAR});
				break;
			}
			case "endTime" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET endTime = ? WHERE testId = ?", new  Object[]{testBean.getExpiryTime(), testBean.getTestId()}, new int[]{Types.VARCHAR, Types.VARCHAR});
				break;
			}
			case "noQues" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET noQues = ? WHERE testId = ?", new  Object[]{testBean.getNoQues(), testBean.getTestId()}, new int[]{Types.INTEGER, Types.VARCHAR});
				break;
			}
			case "showMark" :
			{
//				System.out.println(testBean.getShowMark()+"    ddd"+testBean.getTestId());
//				String sql = "UPDATE "+testTable+" SET showMark = '"+testBean.getShowMark()+"' WHERE testId = '"+testBean.getTestId()+"'";
//				System.out.println(sql);
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET showMark = ? WHERE testId = ?", new  Object[]{testBean.getShowMark(), testBean.getTestId()}, new int[]{Types.VARCHAR, Types.VARCHAR});
				break;
			}
			case "shuffle" :
			{
				num = getJdbcTemplate().update("UPDATE "+testTable+" SET shuffle = ? WHERE testId = ?", new  Object[]{testBean.getShuffle(), testBean.getTestId()}, new int[]{Types.VARCHAR, Types.VARCHAR});
				break;
			}
			default:{
				return -1;
			}
			}
		}
		catch(Throwable e)
		{
			throw new Exception(e.getCause());
		}
		return num;
	}
	
	public int deleteTest(String testId) throws Exception
	{
		int num = 0;
		CreatedTestBean bean = getTestDetailsById(testId);
		if(bean != null)
		{
			//delete testTable
			num = getJdbcTemplate().update("DELETE FROM "+testTable+" WHERE testId = "+testId);
			//delete testStatus
			num = getJdbcTemplate().update("DELETE FROM "+testStatus+" WHERE testId = "+testId);
			//delete testQuestions
			num = getJdbcTemplate().update("DELETE FROM "+testQuestion+" WHERE testId = "+testId); 
		}
		else
			throw new Exception("Record not found for the given testId");
		
		return num;
	}
	
	public int addQuesToTest(String testId, String quesId) throws Exception{
		int num = 0;
		try{
			num = getJdbcTemplate().update("INSERT INTO "+testQuestion+" VALUES (?, ?)", new Object[]{testId, quesId}, new int[]{Types.VARCHAR, Types.VARCHAR});
			if(num == 1){
				int noQues = getNoOfQues(testId);
				
				updateNoQues(testId, noQues);
			}
		}
		catch(Throwable e){
			throw new Exception(e.getCause());
		}
		return num;
	}
public int deleteQuesFromTest(String testId,String quesId) throws Exception
                     {
                     int num = 0;
                    CreatedTestBean bean = getTestDetailsById(testId);
                    if(bean != null)
                    {
                                
                                    //delete testQuestions
                                    num = getJdbcTemplate().update("DELETE FROM "+testQuestion+" WHERE testId = '"+testId+"' and quesId='"+quesId+"'" );
                                    int no = getNoOfQues(testId);
                                    updateNoQues(testId, no);
                    }
                    else
                                    throw new Exception("Record not found for the given testId");
                    
                    return num;
                     }

	
	public int getNoOfQues(String testId){
		return getJdbcTemplate().queryForInt("SELECT COUNT(*) FROM "+testQuestion+" WHERE testId = '"+testId+"'");
	}
	
	public int updateNoQues(String testId, int noQues){
		int num = getJdbcTemplate().update("UPDATE "+testTable+" SET noQues = ? WHERE testId = ?", new  Object[]{noQues, testId}, new int[]{Types.INTEGER, Types.VARCHAR});
		return num;
	}
}
