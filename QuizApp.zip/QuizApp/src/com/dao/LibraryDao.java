package com.dao;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.LibraryMapper;
import com.mapper.QuesId_CatMapper;
import com.model.library.LibraryBean;
import com.model.question.QuestionBean;

@Component
public class LibraryDao extends JdbcDaoSupport{
                String table="QuizApp_Library";
                
                @Autowired
                QuestionDao qDao;
                
                @Autowired
                public LibraryDao(DataSource ds)
                {
                                setDataSource(ds);
                }
                
                
                
                public int createLibrary(LibraryBean lb) throws Exception
                {
                                int res=0;
                                try{
             for(QuestionBean qb:lb.getQuestions() )
             {
                Object []param={qb.getQuesId(),lb.getCommitId(),lb.getStatus(),lb.getCategory(),lb.getTag()};
                res = qDao.createQuestion(qb);
                int [] types={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                res=getJdbcTemplate().update("INSERT into "+table+" Values(?,?,?,?,?)",param,types);
            }
                                }

                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                                
                                return res;
                }
                
                
                public List<LibraryBean> getLibrary(String commitId, String status) throws Exception
                {
                                int res=0;
                                System.out.println(commitId+status);
                                List<LibraryBean> lb = new ArrayList<LibraryBean>() ;
                                List<LibraryBean> finalList = new ArrayList<LibraryBean>() ;
                                try{
                                                String SQL = "select * from "+table+" where  commitId= ? AND status = ?";
                                                lb=getJdbcTemplate().queryForObject(SQL,new Object[]{commitId, status},new int[]{Types.VARCHAR, Types.VARCHAR}, new LibraryMapper());
                                                for(LibraryBean lBean : lb)
                                                {
                                                	lBean.setCommitId(commitId);
                                                	lBean.setStatus(status);
                                                    List<QuestionBean> quesList = new ArrayList<QuestionBean>();

                                                                for(QuestionBean qBean : lBean.getQuestions())
                                                                {                                        
                                                                	System.out.println(qBean.getQuesId());
                                                                                quesList.add(qDao.getQuestion(qBean.getQuesId()));
                                                                }
                                                                lBean.setQuestions(quesList);
                                                                finalList.add(lBean);
                                                }
                                                
                                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                                return finalList;
                                
                }
                
                public List<LibraryBean> getLibraryByCatTag(String commitId, String status, String category, String tag) throws Exception
                {
                                int res=0;
                                List<QuestionBean> quesList = new ArrayList<QuestionBean>();
                                List<LibraryBean> lb = new ArrayList<LibraryBean>() ;
                                List<LibraryBean> finalList = new ArrayList<LibraryBean>() ;
                                try{
                                                String SQL = "select * from "+table+" where  commitId= ? AND status = ? AND category = ? AND tag = ?";
                                                lb=getJdbcTemplate().queryForObject(SQL,new Object[]{commitId, status, category, tag},new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, new LibraryMapper());
                                                for(LibraryBean lBean : lb)
                                                {
                                                	lBean.setCommitId(commitId);
                                                	lBean.setStatus(status);
                                                                for(QuestionBean qBean : lBean.getQuestions())
                                                                {                                                                              
                                                                                quesList.add(qDao.getQuestion(qBean.getQuesId()));
                                                                }
                                                                lBean.setQuestions(quesList);
                                                                finalList.add(lBean);
                                                }
                                                
                                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                                return finalList;
                                
                }
                
                public List<LibraryBean> getLibraryByCat(String commitId, String status, String category) throws Exception
                {
                                int res=0;
                                List<QuestionBean> quesList = new ArrayList<QuestionBean>();
                                List<LibraryBean> lb = new ArrayList<LibraryBean>() ;
                                List<LibraryBean> finalList = new ArrayList<LibraryBean>() ;
                                try{
                                                String SQL = "select * from "+table+" where  commitId= ? AND status = ? AND category = ?";
                                                lb=getJdbcTemplate().queryForObject(SQL,new Object[]{commitId, status, category},new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, new LibraryMapper());
                                                for(LibraryBean lBean : lb)
                                                {
                                                	lBean.setCommitId(commitId);
                                                	lBean.setStatus(status);
                                                                for(QuestionBean qBean : lBean.getQuestions())
                                                                {                                                                              
                                                                                quesList.add(qDao.getQuestion(qBean.getQuesId()));
                                                                }
                                                                lBean.setQuestions(quesList);
                                                                finalList.add(lBean);
                                                }
                                                
                                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                                return finalList;
                                
                }
                public String getCategory(String quesid)

                {

                        String SQL = "select category from "+table+" where  quesId = ?";

                        return getJdbcTemplate().queryForObject(SQL,new Object[]{quesid},new int[]{Types.VARCHAR}, new QuesId_CatMapper());

                    

                }


                public int updateLibrary(LibraryBean lb,String updateField)
                {
                                int num = 0;
                                
                                switch(updateField)
                                {
                                case "category" : 
                                {
                                                                num = getJdbcTemplate().update("UPDATE "+table+" SET category = ? WHERE commitId = ? AND quesId = ?",new Object[]{lb.getCategory(), lb.getCommitId(), lb.getQuestions().get(0).getQuesId()}, new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
                                                                break;
                                }
                                case "tag" :
                                {
                                                                num = getJdbcTemplate().update("UPDATE "+table+" SET tag = ? WHERE commitId = ? AND quesId = ?",new Object[]{lb.getTag(), lb.getCommitId(), lb.getQuestions().get(0).getQuesId()}, new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
                                                                break;
                                }
                                case "status" :
                                {                              num = getJdbcTemplate().update("UPDATE "+table+" SET status = ? WHERE commitId = ? AND quesId = ?",new Object[]{lb.getCategory(), lb.getCommitId(), lb.getQuestions().get(0).getQuesId()}, new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
                                                                break;
                                }
                                default:
                                	return -1;
                                }
                                return num;
                }
                public int delQuestionById(String quesId) throws Exception
                {
                                try{
                                                
                                                int num = getJdbcTemplate().update("DELETE FROM "+table+" WHERE quesId = '"+quesId+"'");
                                                if(num == 1){
                                                                int n=qDao.deleteQuestion(quesId);
                                               
                                                                return n;
                                                              
                                                }
                                                return num; 
                                                
                                }
                                catch(Throwable e)
                                {throw new Exception(e);}
                }
}

