package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import com.dao.QuestionDao;
import com.model.question.Data;
import com.model.question.QuestionBean;
import com.model.question.Response;
import com.model.questionReport.QuestionReportBean;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@RestController
@RequestMapping(value = "/questions")
public class QuestionController {
	@Autowired
	QuestionDao questionDao;
	@Autowired
	MetaData metaData;

	@Autowired
	Data q_data;
	@Autowired
	Response q_response;
	@Autowired 
	Error error;
	private void saveMetaData(boolean success, String description, String responseId){
	 	
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(Data data, MetaData metaData, Error errorDet) {
		q_response.setData(data);
		q_response.setMetaData(metaData);
		q_response.setError(errorDet);
	}
	private void saveData(Error erroDet, List testObj) {
		q_response.setError(erroDet);
	    q_data.setOutput(testObj);
	}
	@ApiOperation(value = "Save a Question Record using POST method",notes = "Create a record ",response=Response.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Response>  addQuestionBean(@RequestBody QuestionBean qBean) {
		
		 
		 
		 
			try{
				
				int r=questionDao.createQuestion(qBean);
				if(r==1){
				saveMetaData(true,"Record inserted","Success124");
				 List<QuestionBean> qList=new ArrayList<QuestionBean>();
				 qList.add(qBean);
				  
					saveData(null, qList);
					saveResponse(q_data,metaData, null);
				  return new  ResponseEntity<Response>(q_response,HttpStatus.CREATED);
				}
				else 
					throw new Exception();
			}catch(Exception e){
				e.printStackTrace();			
				error.setCode("00005");
				 if (e instanceof DataAccessException)
				   {
				error.setDescription("Database Error");
				   }
				 else{
					 error.setDescription(e.getMessage());
				 }
				saveMetaData(false,"Error Occured","e124");
				
				saveResponse(null,metaData, error);
				return new ResponseEntity<Response>(q_response, HttpStatus.NOT_FOUND) ;
			}
			
	
	

      }
	@ApiOperation(value = "retrieve all records using POST method",notes = "Returns the list of questions in Question ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( value="/{quesId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getQuestions(@PathVariable String quesId) {
		ResponseEntity<Response> responseEntity=null;
		
		try{
		List<QuestionBean> QuestionList= new ArrayList<QuestionBean>();
		QuestionBean qb=questionDao.getQuestion(quesId);
		QuestionList.add(qb);
		if(QuestionList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Record not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(q_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"Question loaded","Success123");
			saveData(null, QuestionList);
			saveResponse(q_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(q_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(q_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	 @ApiOperation(value = "Update using PUT method",notes = "Update category,tag and status",response=Response.class)
		@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping(value="/{whatToUpdate}",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
	 @ResponseStatus(value=HttpStatus.CREATED)
	  public ResponseEntity<Response> Update(@ApiParam(value="desc,options,answers,mark,image and difficulty")@PathVariable("whatToUpdate") String whatToUpdate,@RequestBody QuestionBean qb)
	  {
 	  ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
			int num=questionDao.updateQuestions(qb,whatToUpdate);
			List<QuestionBean> QuestionList=new ArrayList<QuestionBean>();
			QuestionList.add(qb);
			if(num==0)
			{

  				error.setCode("Error001");
  	  			error.setDescription("No such record to upadate");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(q_response, HttpStatus.NOT_FOUND) ;
			}
			else if(num==-1)
				
			{

  				error.setCode("Error001");
  	  			error.setDescription("check what to update field");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(q_response, HttpStatus.NOT_FOUND) ;
			
			}
			else
			{
				saveMetaData(true,"Questions updated","Success123");
				saveData(null,QuestionList);
				saveResponse(q_data,metaData, null);
				responseEntity= new  ResponseEntity<Response>(q_response,HttpStatus.OK);
			}
		}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(q_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
 	  
	  }

	   @ApiOperation(value = "Delete a record using DELETE method",notes = "Delete a record usng question id",response=Response.class)
	  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  	  @RequestMapping(value = "/{quesId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	  	  public ResponseEntity<Response> DeleteQuestionReport(@ApiParam(value="questions to be deleted")@PathVariable("quesId") String quesId)
	  	  {
	  		
	  		 
	  		  try{
	  			  List<QuestionBean> list1=new ArrayList<QuestionBean>();
	  			  int num = questionDao.deleteQuestion(quesId);
	  			  if(num==0)
	  			  {
	  				error.setCode("Error001");
	  	  			error.setDescription("Records with this quesId is not found");
	  	  			
	  	              saveMetaData(false,"Error Occured","12345");
	  	  			
	  	  			saveResponse(null,metaData,error);
	  	  			return new ResponseEntity<Response>(q_response, HttpStatus.NOT_FOUND) ;
	  			  }
	  			  else{
	  					saveMetaData(true,"Question deleted","Success123");
	  		  			saveData(null, list1);
	  		  			saveResponse(q_data,metaData, null);
	  		  			return new  ResponseEntity<Response>(q_response,HttpStatus.OK);
	  				}
	  		
	  					
	  			  
	  		  }
	  		  catch(Exception e){
	  			  e.printStackTrace();
	  				error.setCode("00005");
	  				
	  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
	  					error.setDescription("Bad Request(Result size)");
	  				else if( e instanceof DataAccessException)
	  					error.setDescription("Database error");
	  				else{
	  					System.out.println("$$");
	  					error.setDescription(e.getMessage());
	  				}
	  					saveMetaData(false,"Error Occured","e123");
	  				
	  				saveResponse(null,metaData, error);
	  				System.out.println("Exception****"+e.getCause());
	  				return new  ResponseEntity<Response>(q_response,HttpStatus.CONFLICT);
	  			}	
	      	
	        }	



}
