package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.dao.LibraryDao;
import com.dao.QuestionDao;
import com.model.library.Data;
import com.model.library.LibraryBean;
import com.model.library.Response;
import com.model.question.QuestionBean;
import com.model.questionReport.QuestionReportBean;

@EnableSwagger2
@RestController
@RequestMapping(value = "/library")
public class LibraryController {
	@Autowired
	LibraryDao libraryDao;
	@Autowired
	MetaData metaData;
	@Autowired
	QuestionDao questionDao;
	@Autowired
	Data lib_data;
	@Autowired
	Response lib_response;
	@Autowired 
	Error error;
	private void saveMetaData(boolean success, String description, String responseId){
	 	
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(Data data, MetaData metaData, Error errorDet) {
		lib_response.setData(data);
		lib_response.setMetaData(metaData);
		lib_response.setError(errorDet);
	}
	private void saveData(Error erroDet, List testObj) {
		lib_response.setError(erroDet);
	    lib_data.setOutput(testObj);
	}
	@ApiOperation(value = "Save a Question Record using POST method",notes = "Create a record ",response=Response.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Response>  addLibraryBean(@RequestBody LibraryBean libBean) {
		
		 
		 
		 
			try{
				
				int r=libraryDao.createLibrary(libBean);
				if(r==1){
				saveMetaData(true,"Record inserted","Success124");
				 List<LibraryBean> libList=new ArrayList<LibraryBean>();
				 libList.add(libBean);
				  
					saveData(null, libList);
					saveResponse(lib_data,metaData, null);
				  return new  ResponseEntity<Response>(lib_response,HttpStatus.CREATED);
				}
				else 
					throw new Exception();
			}catch(Exception e){
				e.printStackTrace();			
				error.setCode("00005");
				 if (e instanceof DataAccessException)
				   {
				error.setDescription("Database Error");
				   }
				 else{
					 error.setDescription(e.getMessage());
				 }
				saveMetaData(false,"Error Occured","e124");
				
				saveResponse(null,metaData, error);
				return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
			}
			
	
	

      }
	@ApiOperation(value = "retrieve all records using POST method",notes = "Returns the list of questions in library ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( value="/commitId_status",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getQuestions(@RequestBody LibraryBean lb) {
		ResponseEntity<Response> responseEntity=null;
		
		try{
		List<LibraryBean> LibraryList= libraryDao.getLibrary(lb.getCommitId(), lb.getStatus());
		if(LibraryList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"QuestionReports loaded","Success123");
			saveData(null, LibraryList);
			saveResponse(lib_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records by category using POST method",notes = "Returns the list of questions in library ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( value="/category",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getQuestions_cat(@RequestBody LibraryBean lb) {
		ResponseEntity<Response> responseEntity=null;
		
		try{
		List<LibraryBean> LibraryList= libraryDao.getLibraryByCat(lb.getCommitId(), lb.getStatus(),lb.getCategory());
		if(LibraryList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"Questions loaded","Success123");
			saveData(null, LibraryList);
			saveResponse(lib_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records by category using POST method",notes = "Returns the list of questions in library ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( value="/categoryTag",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getQuestions_cattag(@RequestBody LibraryBean lb) {
		ResponseEntity<Response> responseEntity=null;
		
		try{
		List<LibraryBean> LibraryList= libraryDao.getLibraryByCatTag(lb.getCommitId(), lb.getStatus(),lb.getCategory(),lb.getTag());
		if(LibraryList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"Questions loaded","Success123");
			saveData(null, LibraryList);
			saveResponse(lib_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	 @ApiOperation(value = "Update using PUT method",notes = "Update category,tag and status",response=Response.class)
		@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping(value="/{whatToUpdate}",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
	 @ResponseStatus(value=HttpStatus.CREATED)
	  public ResponseEntity<Response> Update(@ApiParam(value="category,tag or status")@PathVariable("whatToUpdate") String whatToUpdate,@RequestBody LibraryBean lb)
	  {
 	  ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
			int num=libraryDao.updateLibrary(lb,whatToUpdate);
			List<LibraryBean> LibraryList=new ArrayList<LibraryBean>();
			LibraryList.add(lb);
			if(num==0)
			{

  				error.setCode("Error001");
  	  			error.setDescription("No such record to upadate");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
			}
			else if(num==-1)
				
			{

  				error.setCode("Error001");
  	  			error.setDescription("check what to update field");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
			
			}
			else
			{
				saveMetaData(true,"Questions updtaed","Success123");
				saveData(null,LibraryList);
				saveResponse(lib_data,metaData, null);
				responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.OK);
			}
		}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(lib_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
 	  
	  }

	   @ApiOperation(value = "Delete a record using DELETE method",notes = "Delete a record usng question id",response=Response.class)
	  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  	  @RequestMapping(value = "/{quesId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	  	  public ResponseEntity<Response> DeleteQuestionReport(@ApiParam(value="questions to be deleted")@PathVariable("quesId") String quesId)
	  	  {
	  		
	  		 
	  		  try{

	  			List<QuestionBean> list1=new ArrayList<QuestionBean>();
	  			QuestionBean qb=questionDao.getQuestion(quesId);
	  			list1.add(qb);
	  			  int num = libraryDao.delQuestionById(quesId);
	  			  if(num==0)
	  			  {
	  				error.setCode("Error001");
	  	  			error.setDescription("Records with this quesId is not found");
	  	  			
	  	              saveMetaData(false,"Error Occured","12345");
	  	  			
	  	  			saveResponse(null,metaData,error);
	  	  			return new ResponseEntity<Response>(lib_response, HttpStatus.NOT_FOUND) ;
	  			  }
	  			  else{
	  					saveMetaData(true,"QuestionReport updated","Success123");
	  		  			saveData(null, list1);
	  		  			saveResponse(lib_data,metaData, null);
	  		  			return new  ResponseEntity<Response>(lib_response,HttpStatus.OK);
	  				}
	  		
	  					
	  			  
	  		  }
	  		  catch(Exception e){
	  			  e.printStackTrace();
	  				error.setCode("00005");
	  				
	  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
	  					error.setDescription("Bad Request(Result size)");
	  				else if( e instanceof DataAccessException)
	  					error.setDescription("Database error");
	  				else{
	  					System.out.println("$$");
	  					error.setDescription(e.getMessage());
	  				}
	  					saveMetaData(false,"Error Occured","e123");
	  				
	  				saveResponse(null,metaData, error);
	  				System.out.println("Exception****"+e.getCause());
	  				return new  ResponseEntity<Response>(lib_response,HttpStatus.CONFLICT);
	  			}	
	      	
	        }	

	
}
