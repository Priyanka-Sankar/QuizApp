package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.dao.TestReportDao;
import com.model.testReport.Data;
import com.model.testReport.Response;
import com.model.testReport.TestReportBean;

import springfox.documentation.swagger2.annotations.EnableSwagger2;



@EnableSwagger2
@RestController
@RequestMapping(value = "/testReports")
public class TestReportController {
	@Autowired
	TestReportDao tReportDao;
	@Autowired
	MetaData metaData;

	@Autowired
	Data tr_data;
	@Autowired
	Response tr_response;
	@Autowired 
	Error error;
private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(Data data, MetaData metaData, Error errorDet) {
		tr_response.setData(data);
		tr_response.setMetaData(metaData);
		tr_response.setError(errorDet);
	}
	private void saveData(Error erroDet, List testObj) {
		tr_response.setError(erroDet);
			tr_data.setOutput(testObj);
	}
	@ApiOperation(value = "Save a TestReport using POST method",notes = "Creates an entry for a test ",response=Response.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Response>  addTestReport(@RequestBody TestReportBean tRBean) {
		
		 
		 
		 
			try{
				List<TestReportBean> trbl=tReportDao.getReport(tRBean);
				System.out.println("after check");
				if(!trbl.isEmpty())
				{
					error.setCode("Error000");
					error.setDescription("Record with this cid,tid and qid is already present");
					
		            saveMetaData(false,"Error Occured","12345");
					
					saveResponse(null,metaData,error);
					return new ResponseEntity<Response>(tr_response, HttpStatus.CONFLICT) ;
				}
				int r=tReportDao.insertTReport(tRBean);
				System.out.println("after insert");
				if(r==1){
				saveMetaData(true,"Report inserted","Success124");
				 List<TestReportBean> tRList=new ArrayList<TestReportBean>();
				 tRList.add(tRBean);
				  
					saveData(null, tRList);
					saveResponse(tr_data,metaData, null);
				  return new  ResponseEntity<Response>(tr_response,HttpStatus.CREATED);
				}
				else 
					throw new Exception();
			}catch(Exception e){
				e.printStackTrace();			
				error.setCode("00005");
				 if (e instanceof DataAccessException)
				   {
				error.setDescription("Database Error");
				   }
				 else{
					 error.setDescription(e.getMessage());
				 }
				saveMetaData(false,"Error Occured","e124");
				
				saveResponse(null,metaData, error);
				return new ResponseEntity<Response>(tr_response, HttpStatus.NOT_FOUND) ;
			}
			
	
	

      }
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of TestReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getAllTestReports() {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<TestReportBean> TestReportList= tReportDao.getReport();
		if(TestReportList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(tr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"TestReports loaded","Success123");
			saveData(null, TestReportList);
			saveResponse(tr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of TestReports ",response=Response.class)

    @ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })

      @RequestMapping( value="check",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE )

     public ResponseEntity<Response> getAtest(@RequestBody TestReportBean tb) {

            ResponseEntity<Response> responseEntity=null;

            Error error= new Error();

            try{

            int i= tReportDao.getaTest(tb.getTestId(), tb.getCommitId());

    

            List a= new ArrayList<Integer>();

            a.add(new Integer(i));

                    saveMetaData(true,"TestReports loaded","Success123");

                    saveData(null,a);

                    saveResponse(tr_data,metaData, null);

                    responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.OK);

            }       

            

    catch (Exception e) {

                            // TODO Auto-generated catch block

                            e.printStackTrace();

                            error.setCode("00005");

                            

                            if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)

                                    error.setDescription("Bad Request(Result Size)");

                            else if( e instanceof DataAccessException)

                                    error.setDescription("Database error");

                            else

                                    error.setDescription(e.getMessage());;

                            saveMetaData(false,"Error Occured","e123");

                            

                            saveResponse(null,metaData, error);

                            responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.CONFLICT);

                            

                    }

            

            return responseEntity;

            

            

  } 


	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of TestReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="/rank",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getRank(@RequestBody TestReportBean tb) {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<TestReportBean> l= tReportDao.getRank(tb.getTestId(), tb.getCommitId());
		int i=0;
		int c=0;
		System.out.println(l.size());
		for(int j=0;j<l.size();j++)
		{
			
			
			i++;
			if(((TestReportBean)l.get(j)).getCommitId().equals(tb.getCommitId()))
			{
				c=1;
				break;
			}
		}

		List<Integer> rank=new ArrayList<Integer>();
		//rank.add(new Integer(i));
		if(c==0){
			rank.add(new Integer(c));
			saveMetaData(true,"TestReports loaded","Success123");
			saveData(null, rank);
			saveResponse(tr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.OK);
			
		}
		else{
			rank.add(new Integer(i));
			saveMetaData(true,"TestReports loaded","Success123");
			saveData(null, rank);
			saveResponse(tr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of TestReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="/{commitId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getTestReports(@PathVariable String commitId) {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<TestReportBean> TestReportList= tReportDao.getReport(commitId);
		if(TestReportList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(tr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			for(TestReportBean t:TestReportList)
			{
				List<TestReportBean> l= tReportDao.getRank(t.getTestId(), t.getCommitId());
				int i=0;
				int c=0;
				System.out.println(l.size());
				for(int j=0;j<l.size();j++)
				{
					
					
					i++;
					if(((TestReportBean)l.get(j)).getCommitId().equals(t.getCommitId()))
					{
						c=1;
						break;
					}
				}
				if(c==1)
				{
					t.setRank(i);
				}
				else
				{
					t.setRank(0);
				}
			}
			saveMetaData(true,"TestReports loaded","Success123");
			saveData(null, TestReportList);
			saveResponse(tr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of TestReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="/test/{testId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getTestReport(@PathVariable String testId) {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<TestReportBean> TestReportList= tReportDao.getReportTestId(testId);
		if(TestReportList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(tr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			for(TestReportBean t:TestReportList)
			{
				List<TestReportBean> l= tReportDao.getRank(t.getTestId(), t.getCommitId());
				int i=0;
				int c=0;
				System.out.println(l.size());
				for(int j=0;j<l.size();j++)
				{
					
					
					i++;
					if(((TestReportBean)l.get(j)).getCommitId().equals(t.getCommitId()))
					{
						c=1;
						break;
					}
				}
				if(c==1)
				{
					t.setRank(i);
				}
				else
				{
					t.setRank(0);
				}
			}
			saveMetaData(true,"TestReports loaded","Success123");
			saveData(null, TestReportList);
			saveResponse(tr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(tr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
      @ApiOperation(value = "Delete a TestReport using DELETE method",notes = "Delete a TestReport",response=Response.class)
  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
  	  @RequestMapping(value = "/{commitId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
  	  public ResponseEntity<Response> DeleteTestReport(@ApiParam(value="commitId whose qreports are to be deleted")@PathVariable("commitId") String commitId)
  	  {
  		Error error= new Error();
  		 
  		  try{
  			  List<TestReportBean> list1=new ArrayList<TestReportBean>();
  			  list1 = tReportDao.getReport(commitId);
  			  if(list1.isEmpty())
  			  {

  	  			error.setCode("Error001");
  	  			error.setDescription("Records with this cid is not found");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(tr_response, HttpStatus.NOT_FOUND) ;
  			  }
  			  else
  			  {
  				int r=tReportDao.delete(commitId);
  				if(r==1)
  				{
  					saveMetaData(true,"TestReport deleted","Success123");
  		  			saveData(null, list1);
  		  			saveResponse(tr_data,metaData, null);
  		  			return new  ResponseEntity<Response>(tr_response,HttpStatus.OK);
  				}
  				else
  				{
  					error.setCode("Error001");
  	  	  			error.setDescription("Records with this cid is not found");
  	  	  			
  	  	              saveMetaData(false,"Error Occured","12345");
  	  	  			
  	  	  			saveResponse(null,metaData,error);
  	  	  			return new ResponseEntity<Response>(tr_response, HttpStatus.NOT_FOUND) ;
  				}
  					
  			  }
  		  }
  		  catch(Exception e){
  			  e.printStackTrace();
  				error.setCode("00005");
  				
  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
  					error.setDescription("Bad Request(Result size)");
  				else if( e instanceof DataAccessException)
  					error.setDescription("Database error");
  				else{
  					System.out.println("$$");
  					error.setDescription(e.getMessage());
  				}
  					saveMetaData(false,"Error Occured","e123");
  				
  				saveResponse(null,metaData, error);
  				System.out.println("Exception****"+e.getCause());
  				return new  ResponseEntity<Response>(tr_response,HttpStatus.CONFLICT);
  			}	
      	
        }	
}
