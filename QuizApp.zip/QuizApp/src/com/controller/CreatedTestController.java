package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.dao.CreatedTestDao;
import com.model.createdTest.CreatedTestBean;
import com.model.createdTest.Data;
import com.model.createdTest.Response;
import com.model.question.QuestionBean;

@EnableSwagger2
@RestController
@RequestMapping(value = "/createdTest")
public class CreatedTestController {

	@Autowired
	CreatedTestDao cdao;
	
	@Autowired
	MetaData metaData;
	
	@Autowired
	Error error;
	
	@Autowired
	Data ct_data;
	
	@Autowired
	Response ct_resp;
	
	@ApiOperation(value = "Save a Test using POST method",notes = "Create test data ",response=Response.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> insert(@RequestBody CreatedTestBean testBean)
	{
		List<CreatedTestBean> testList = new ArrayList<CreatedTestBean>();
		try{
			System.out.println();
			CreatedTestBean bean = cdao.createTest(testBean);
			
			testList.add(bean);
			saveMetaData(true, "Test Created", "12345");
			saveData(null, testList);
			error.setDescription(null);
			error.setCode(null);
			saveResponse(metaData, ct_data, error);
			
		}
		catch(Exception e)
		{
			System.out.println("Exception occuredd");
			//e.printStackTrace();
			 if (e instanceof DataAccessException)
			   {
			error.setDescription("Database Error");
			   }
			 else{
				 error.setDescription(e.getMessage());
			 }
			error.setCode("12345");
			saveMetaData(false, "Test not created", "12345");
			saveResponse(metaData, null, error);
			return  new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
		}
		return  new ResponseEntity<Response>(ct_resp, HttpStatus.OK) ;
	}
	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of tests ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="/{commitId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getTest(@PathVariable String commitId) {
		ResponseEntity<Response> responseEntity=null;
		List<CreatedTestBean> beanList = new ArrayList<CreatedTestBean>();
		try{
		 beanList = cdao.getTestByCommitId(commitId);
			for(QuestionBean qb :beanList.get(0).getQuestions())
			{
				
				System.out.println("ins for3");

				System.out.println(qb.getQuesId());
				
			}

		 if(!beanList.isEmpty()){
		 saveMetaData(true,"Tests loaded","Success123");
			saveData(null, beanList);
			saveResponse(metaData, ct_data, null);
			responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
			}
		else
		{
			error.setCode("00005");
			error.setDescription("Test with commitId is not present");
			saveMetaData(true,"Tests not loaded","error123");
			saveData(null,null);
			saveResponse(metaData, null, error);
			responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.NOT_FOUND);
		}
	}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(metaData, null, error);
				responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }

    @ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of tests ",response=Response.class)
    @ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @RequestMapping( value="/testId/{testId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Response> getTestByTestId(@PathVariable String testId) {
                    ResponseEntity<Response> responseEntity=null;
                    CreatedTestBean cb=new CreatedTestBean();
                    List<QuestionBean> beanList = new ArrayList<QuestionBean>();
                    List<CreatedTestBean> ctBeanList = new ArrayList<CreatedTestBean>();
                    try{
                      cb=cdao.getTestDetailsById(testId);
                    beanList = cdao.getQuestionsByTestId(testId);
                    cb.setQuestions(beanList);
                    cb.setNoQues(beanList.size());
                    ctBeanList.add(cb);
                    if(!ctBeanList.isEmpty()){
                    saveMetaData(true,"Test Details loaded","Success123");
                                    saveData(null,ctBeanList);
                                    saveResponse(metaData, ct_data, null);
                                    responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
                                    }
                    else
                    {
                                    error.setCode("00005");
                                    error.setDescription("No such test id");
                                    saveMetaData(true,"Please check the test id","error123");
                                    saveData(null,null);
                                    saveResponse(metaData, null, error);
                                    responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.NOT_FOUND);
                    }
    }
                                    catch (Exception e) {
                                                    // TODO Auto-generated catch block
                                                    e.printStackTrace();
                                                    error.setCode("00005");
                                                    
                                                    if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
                                                    {    saveMetaData(false,"No data","e123");        
                                                         error.setDescription("Bad Request(Result Size)");
                                                    }
                                                    else if( e instanceof DataAccessException)
                                                    {
                                                                    error.setDescription("Database error");
                                                                    saveMetaData(false,"Database error","e123");
                                                    }else{
                                                                    error.setDescription(e.getMessage());
                                                    saveMetaData(false,"Error Occured","e123");
                                                    }
                                                    saveResponse(metaData, null, error);
                                                    responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
                                                    
                                    }
                   
                    return responseEntity;
                    
                    
}
    
@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of tests ",response=Response.class)
    @ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @RequestMapping(value="/all/{commitId}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Response> getTests(@ApiParam(value="lists the available tests for the given commitId")@PathVariable("commitId") String commitId) {
                    ResponseEntity<Response> responseEntity=null;
                    List<CreatedTestBean> beanList = new ArrayList<CreatedTestBean>();
                    try{
                    beanList = cdao.getTest(commitId);
                                    for(QuestionBean qb :beanList.get(0).getQuestions())
                                    {
                                                    
                                                    System.out.println("ins for3");

                                                    System.out.println(qb.getQuesId());
                                                    
                                    }

                    if(!beanList.isEmpty()){
                    saveMetaData(true,"Tests loaded","Success123");
                                    saveData(null, beanList);
                                    saveResponse(metaData, ct_data, null);
                                    responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
                                    }
                    else
                    {
                                    error.setCode("00005");
                                    error.setDescription("Test with commitId is not present");
                                    saveMetaData(true,"Tests not loaded","error123");
                                    saveData(null,null);
                                    saveResponse(metaData, null, error);
                                    responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.NOT_FOUND);
                    }
    }
                                    catch (Exception e) {
                                                    // TODO Auto-generated catch block
                                                    e.printStackTrace();
                                                    error.setCode("00005");
                                                    
                                                    if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
                                                                    error.setDescription("Bad Request(Result Size)");
                                                    else if( e instanceof DataAccessException)
                                                                    error.setDescription("Database error");
                                                    else
                                                                    error.setDescription(e.getMessage());
                                                    saveMetaData(false,"Error Occured","e123");
                                                    
                                                    saveResponse(metaData, null, error);
                                                    responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
                                                    
                                    }
                    
                    return responseEntity;
                    
                    
}


	@ApiOperation(value = "Update test entry using PUT method",notes = "Update test entry",response=Response.class)
	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
  @RequestMapping(value="/{whatToUpdate}",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
 @ResponseStatus(value=HttpStatus.CREATED)
  public ResponseEntity<Response> UpdateMeaning(@ApiParam(value="score or answer")@PathVariable("whatToUpdate") String whatToUpdate,@RequestBody CreatedTestBean test)
  {
	  ResponseEntity<Response> responseEntity=null;
		
		try{
			CreatedTestBean bean = cdao.getTestDetailsById(test.getTestId());
		if(bean == null){
			
			error.setCode("Error001");
			error.setDescription("Record with testId not found");
			
          saveMetaData(false,"Error Occured","12345");
			
			saveResponse(metaData,null,error);
			return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			int r=cdao.updateTest(test, whatToUpdate);
			if(r!=-1)
			{
			List<CreatedTestBean> testList = new ArrayList<CreatedTestBean>();
			testList.add(cdao.getTestDetailsById(test.getTestId()));
			saveMetaData(true,"QuestionReport updated","Success123");
			saveData(null, testList);
			saveResponse(metaData, ct_data, null);
			responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
			}
			else
			{
				error.setCode("Error001");
	  			error.setDescription("check whatToUpdate");
	  			
	              saveMetaData(false,"Error Occured","12345");
	  			
	  			saveResponse(metaData,null,error);
	  			return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
			}
		   }	
		}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(metaData, null,error);
				responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
	  
  }
	
	@ApiOperation(value = "Add questions to Test using PUT method",notes = "Update test entry",response=Response.class)
	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
  @RequestMapping(method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
 @ResponseStatus(value=HttpStatus.CREATED)
  public ResponseEntity<Response> addQuesToTest(@RequestBody CreatedTestBean test)
  {
		System.out.println("calleleddddd");
	  ResponseEntity<Response> responseEntity=null;
		
		try{
			CreatedTestBean bean = cdao.getTestDetailsById(test.getTestId());
		if(bean == null){
			
			error.setCode("Error001");
			error.setDescription("Record with testId not found");
			
          saveMetaData(false,"Error Occured","12345");
			
			saveResponse(metaData,null,error);
			return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			int r=0;
			for(QuestionBean qBean : test.getQuestions()){
				List data = cdao.getQuestionsByTestId(test.getTestId());
				if(data.isEmpty()){
				r=cdao.addQuesToTest(test.getTestId(), qBean.getQuesId());
				if(r==-1)
					break;
			}
			}
			if(r!=-1)
			{
			List<CreatedTestBean> testList = new ArrayList<CreatedTestBean>();
			testList.add(cdao.getTestDetailsById(test.getTestId()));
			saveMetaData(true,"QUestions added to test","Success123");
			saveData(null, testList);
			saveResponse(metaData, ct_data, null);
			responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
			}
			else
			{
				error.setCode("Error001");
	  			error.setDescription("Error in updation");
	  			
	              saveMetaData(false,"Error Occured","12345");
	  			
	  			saveResponse(metaData,null,error);
	  			return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
			}
		   }	
		}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(metaData, null,error);
				responseEntity= new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
	  
  }
	
	
	
	 @ApiOperation(value = "Delete a QuestionReport using DELETE method",notes = "Delete a QuestionReport",response=Response.class)
	  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  	  @RequestMapping(value = "/{testId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	  	  public ResponseEntity<Response> DeleteQuestionReport(@ApiParam(value="testId of the test details to be deleted")@PathVariable("testId") String testId)
	  	  {
					  try{
	  			  //List<CreatedTestBean> list1=new ArrayList<CreatedTestBean>();
	  			  CreatedTestBean bean = cdao.getTestDetailsById(testId);
	  			  if(bean == null)
	  			  {

	  	  			error.setCode("Error001");
	  	  			error.setDescription("Records with this testid is not found");
	  	  			
	  	              saveMetaData(false,"Error Occured","12345");
	  	  			
	  	  			saveResponse(metaData,null,error);
	  	  			return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
	  			  }
	  			  else
	  			  {
	  				int r=cdao.deleteTest(testId);
	  				if(r==1)
	  				{
	  					saveMetaData(true,"testDetails deleted","Success123");
	  		  			saveData(null, null);
	  		  			saveResponse(metaData, null,null);
	  		  			return new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
	  				}
	  				else
	  				{
	  					error.setCode("Error001");
	  	  	  			error.setDescription("Records with this cid is not found");
	  	  	  			
	  	  	              saveMetaData(false,"Error Occured","12345");
	  	  	  			
	  	  	  			saveResponse(metaData,null,error);
	  	  	  			return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
	  				}
	  					
	  			  }
	  		  }
	  		  catch(Exception e){
	  			  e.printStackTrace();
	  				error.setCode("00005");
	  				
	  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
	  					error.setDescription("Bad Request(Result size)");
	  				else if( e instanceof DataAccessException)
	  					error.setDescription("Database error");
	  				else{
	  					System.out.println("$$");
	  					error.setDescription(e.getMessage());
	  				}
	  					saveMetaData(false,"Error Occured","e123");
	  				
	  				saveResponse(metaData, null,error);
	  				System.out.println("Exception****"+e.getCause());
	  				return new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
	  			}	
	      	
	        }
	@ApiOperation(value = "Delete a QuestionReport using DELETE method",notes = "Delete a QuestionReport",response=Response.class)
                @ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
                  @RequestMapping(value="/del",method = RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
                  public ResponseEntity<Response> DeleteQuestionTEst(@ApiParam(value="testId and quesid of the test details to be deleted")@RequestBody CreatedTestBean ctb )
                  {
                                                                  try{
                                                  //List<CreatedTestBean> list1=new ArrayList<CreatedTestBean>();
                                                  CreatedTestBean bean = cdao.getTestDetailsById(ctb.getTestId());
                                                  if(bean == null)
                                                  {

                                                                error.setCode("Error001");
                                                                error.setDescription("Records with this testid is not found");
                                                                
                              saveMetaData(false,"Error Occured","12345");
                                                                
                                                                saveResponse(metaData,null,error);
                                                                return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
                                                  }
                                                  else
                                                  {
                                                                int r=cdao.deleteQuesFromTest(ctb.getTestId(), ctb.getQuestions().get(0).getQuesId());
                                                                if(r==1)
                                                                {
                                                                                saveMetaData(true,"question in test deleted","Success123");
                                                                                saveData(null, null);
                                                                                saveResponse(metaData, null,null);
                                                                                return new  ResponseEntity<Response>(ct_resp,HttpStatus.OK);
                                                                }
                                                                else
                                                                {
                                                                                error.setCode("Error001");
                                                                                error.setDescription("Records with this cid is not found");
                                                                                
                                              saveMetaData(false,"Error Occured","12345");
                                                                                
                                                                                saveResponse(metaData,null,error);
                                                                                return new ResponseEntity<Response>(ct_resp, HttpStatus.NOT_FOUND) ;
                                                                }
                                                                                
                                                  }
                                  }
                                  catch(Exception e){
                                                  e.printStackTrace();
                                                                error.setCode("00005");
                                                                
                                                                if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
                                                                                error.setDescription("Bad Request(Result size)");
                                                                else if( e instanceof DataAccessException)
                                                                                error.setDescription("Database error");
                                                                else{
                                                                                System.out.println("$$");
                                                                               error.setDescription(e.getMessage());
                                                                }
                                                                                saveMetaData(false,"Error Occured","e123");
                                                                
                                                                saveResponse(metaData, null,error);
                                                                System.out.println("Exception****"+e.getCause());
                                                                return new  ResponseEntity<Response>(ct_resp,HttpStatus.CONFLICT);
                                                }              
                
        }      

	
private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(MetaData metaData, Data data, Error error) {
		ct_resp.setData(data);
		ct_resp.setMetaData(metaData);
		ct_resp.setError(error);
	}
	private void saveData(Error erroDet, List testObj) {
		ct_resp.setError(erroDet);
			ct_data.setOutput(testObj);
	}

}
