package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.dao.QuestionReportDao;
import com.dao.TestReportDao;
import com.model.questionReport.Data;
import com.model.questionReport.QuestionReportBean;
import com.model.questionReport.Response;

@EnableSwagger2
@RestController
@RequestMapping(value = "/questionReport")
public class QuestionReportController {
	@Autowired
	QuestionReportDao qReportDao;
	@Autowired
	TestReportDao tReportDao;
	@Autowired
	MetaData metaData;

	@Autowired
	Data qr_data;
	@Autowired
	Response qr_response;
	@Autowired 
	Error error;
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(Data data, MetaData metaData, Error errorDet) {
		qr_response.setData(data);
		qr_response.setMetaData(metaData);
		qr_response.setError(errorDet);
	}
	private void saveData(Error erroDet, List testObj) {
		qr_response.setError(erroDet);
			qr_data.setOutput(testObj);
	}
	
	@ApiOperation(value = "Save a QuestionReport using POST method",notes = "Create student data ",response=Response.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Response>  addQuestionReport(@RequestBody QuestionReportBean qRBean) {
		
		 
		 
		 
			try{
				List<QuestionReportBean> qrbl=qReportDao.getCTQReport(qRBean);
				if(!qrbl.isEmpty())
				{
					error.setCode("Error000");
					error.setDescription("Record with this cid,tid and qid is already present");
					
		            saveMetaData(false,"Error Occured","12345");
					
					saveResponse(null,metaData,error);
					return new ResponseEntity<Response>(qr_response, HttpStatus.CONFLICT) ;
				}
				int r=qReportDao.insertQReport(qRBean);
				if(r==1){
				saveMetaData(true,"Report inserted","Success124");
				 List<QuestionReportBean> qRList=new ArrayList<QuestionReportBean>();
				 qRList=qReportDao.getCTQReport(qRBean);
				  
					saveData(null, qRList);
					saveResponse(qr_data,metaData, null);
				  return new  ResponseEntity<Response>(qr_response,HttpStatus.CREATED);
				}
				else 
					throw new Exception();
			}catch(Exception e){
				e.printStackTrace();			
				error.setCode("00005");
				 if (e instanceof DataAccessException)
				   {
				error.setDescription("Database Error");
				   }
				 else{
					 error.setDescription(e.getMessage());
				 }
				saveMetaData(false,"Error Occured","e124");
				
				saveResponse(null,metaData, error);
				return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
			}
			
	
	

      }
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of QuestionReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getAllQuestionReports() {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<QuestionReportBean> QuestionReportList= qReportDao.getReport();
		if(QuestionReportList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"QuestionReports loaded","Success123");
			saveData(null, QuestionReportList);
			saveResponse(qr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of QuestionReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="/{commitId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getQuestionReports(@PathVariable String commitId) {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<QuestionReportBean> QuestionReportList= qReportDao.getReportCommitId(commitId);
		if(QuestionReportList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"QuestionReports loaded","Success123");
			saveData(null, QuestionReportList);
			saveResponse(qr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of QuestionReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="catScore/{commitId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getCatScore(@PathVariable String commitId) {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		Map<String,Integer> catScore= qReportDao.getCatScore(commitId);
		List<Map<String,Integer>> list =new ArrayList<Map<String,Integer>>();
		if(catScore.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			list.add(catScore);
			saveMetaData(true,"QuestionReports loaded","Success123");
			saveData(null, list);
			saveResponse(qr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of QuestionReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="tScore",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> gettScore() {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		Map<String,Integer> catScore= tReportDao.getTScore();
		List<Map<String,Integer>> list =new ArrayList<Map<String,Integer>>();
		if(catScore.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			list.add(catScore);
			saveMetaData(true,"QuestionReports loaded","Success123");
			saveData(null, list);
			saveResponse(qr_data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "Update score or answer of a report using PUT method",notes = "Update score or answer",response=Response.class)
		@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping(value="/{whatToUpdate}",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
	 @ResponseStatus(value=HttpStatus.CREATED)
	  public ResponseEntity<Response> UpdateMeaning(@ApiParam(value="score or answer")@PathVariable("whatToUpdate") String whatToUpdate,@RequestBody QuestionReportBean qrb)
	  {
    	  ResponseEntity<Response> responseEntity=null;
  		Error error= new Error();
  		try{
  			List<QuestionReportBean> qrbl=qReportDao.getCTQReport(qrb);
  		if(qrbl.isEmpty()){
  			
  			error.setCode("Error001");
  			error.setDescription("Record with this cid,tid and qid not found");
  			
              saveMetaData(false,"Error Occured","12345");
  			
  			saveResponse(null,metaData,error);
  			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
  			
  		}
  		else{
  			int r=qReportDao.update(whatToUpdate, qrb);
  			if(r!=-1)
  			{
  			List<QuestionReportBean> qrbList=qReportDao.getCTQReport(qrb);
  			saveMetaData(true,"QuestionReport updated","Success123");
  			saveData(null, qrbList);
  			saveResponse(qr_data,metaData, null);
  			responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.OK);
  			}
  			else
  			{
  				error.setCode("Error001");
  	  			error.setDescription("check whatToUpdate(score or answer)");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
  			}
  		   }	
  		}
  		
  			catch (Exception e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  				error.setCode("00005");
  				
  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
  					error.setDescription("Bad Request(Result Size)");
  				else if( e instanceof DataAccessException)
  					error.setDescription("Database error");
  				else
  					error.setDescription(e.getMessage());;
  				saveMetaData(false,"Error Occured","e123");
  				
  				saveResponse(null,metaData, error);
  				responseEntity= new  ResponseEntity<Response>(qr_response,HttpStatus.CONFLICT);
  				
  			}
  		
  		return responseEntity;
  		
    	  
	  }
      @ApiOperation(value = "Delete a QuestionReport using DELETE method",notes = "Delete a QuestionReport",response=Response.class)
  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
  	  @RequestMapping(value = "/{commitId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
  	  public ResponseEntity<Response> DeleteQuestionReport(@ApiParam(value="commitId whose qreports are to be deleted")@PathVariable("commitId") String commitId)
  	  {
  		Error error= new Error();
  		 
  		  try{
  			  List<QuestionReportBean> list1=new ArrayList<QuestionReportBean>();
  			  list1 = qReportDao.getReportCommitId(commitId);
  			  if(list1.isEmpty())
  			  {

  	  			error.setCode("Error001");
  	  			error.setDescription("Records with this cid is not found");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(null,metaData,error);
  	  			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
  			  }
  			  else
  			  {
  				int r=qReportDao.delete(commitId);
  				if(r==1)
  				{
  					saveMetaData(true,"QuestionReport deleted","Success123");
  		  			saveData(null, list1);
  		  			saveResponse(qr_data,metaData, null);
  		  			return new  ResponseEntity<Response>(qr_response,HttpStatus.OK);
  				}
  				else
  				{
  					error.setCode("Error001");
  	  	  			error.setDescription("Records with this cid is not found");
  	  	  			
  	  	              saveMetaData(false,"Error Occured","12345");
  	  	  			
  	  	  			saveResponse(null,metaData,error);
  	  	  			return new ResponseEntity<Response>(qr_response, HttpStatus.NOT_FOUND) ;
  				}
  					
  			  }
  		  }
  		  catch(Exception e){
  			  e.printStackTrace();
  				error.setCode("00005");
  				
  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
  					error.setDescription("Bad Request(Result size)");
  				else if( e instanceof DataAccessException)
  					error.setDescription("Database error");
  				else{
  					System.out.println("$$");
  					error.setDescription(e.getMessage());
  				}
  					saveMetaData(false,"Error Occured","e123");
  				
  				saveResponse(null,metaData, error);
  				System.out.println("Exception****"+e.getCause());
  				return new  ResponseEntity<Response>(qr_response,HttpStatus.CONFLICT);
  			}	
      	
        }	
}
