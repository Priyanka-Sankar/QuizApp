package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.dao.UserDao;
import com.model.user.Data;
import com.model.user.Response;
import com.model.user.UserBean;
//@CrossOrigin
@EnableSwagger2
@RestController
@RequestMapping(value = "/users")
public class UserController {
	
	@Autowired
	UserDao userDao;
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data  u_data;
	@Autowired
	Response u_response;
	@Autowired 
	Error error;
	
	@RequestMapping (method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "insert a new book object into the database", notes = "More notes about this method", response = Response.class)
	@ApiParam(name="book", value = "user object", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "some thing went wrong", response = Response.class),
		    @ApiResponse(code = 404, message = "some thing went wrong", response = Response.class),
		    @ApiResponse(code = 400, message = "Bad Request", response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error", response = Response.class)}
		)
	@ResponseStatus( value = HttpStatus.CREATED)
	public ResponseEntity<Response> login(@RequestBody UserBean userBean)
	{
		
		try{
			System.out.println();
			int status = userDao.getUser(userBean.getCommitId(), userBean.getPassword());
			saveMetaData(true, "Valid user", "12345");
			saveData(null, null);
			error.setDescription(null);
			error.setCode(null);
			saveResponse(metaData, error, u_data);
			
		}
		catch(Exception e)
		{
			System.out.println("Exception occuredd");
			e.printStackTrace();
			 if (e instanceof DataAccessException)
			   {
			error.setDescription("Database Error");
			   }
			 else{
				 error.setDescription(e.getMessage());
			 }
			error.setCode("12345");
			saveMetaData(false, "Invalid user", "12345");
			saveResponse(metaData, error, null);
			return  new ResponseEntity<Response>(u_response, HttpStatus.NOT_FOUND) ;
		}
		return  new ResponseEntity<Response>(u_response, HttpStatus.OK) ;
	}
	
private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(MetaData metaData, Error error, Data data) {
		u_response.setData(data);
		u_response.setMetaData(metaData);
		u_response.setError(error);
	}
	private void saveData(Error erroDet, List testObj) {
		u_response.setError(erroDet);
			u_data.setOutput(testObj);
	}
}
