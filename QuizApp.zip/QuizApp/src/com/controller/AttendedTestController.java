package com.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.dao.AttendedTestDao;
import com.model.attendedTest.AttendedTestBean;
import com.model.attendedTest.Data;
import com.model.attendedTest.Response;

@EnableSwagger2
@RestController
@RequestMapping(value = "/attendedTest")
public class AttendedTestController {
	
	@Autowired
	AttendedTestDao attendTestDao;
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data at_data;
	
	@Autowired
	Response at_resp;
	
	@Autowired 
	Error error;
	
	@ApiOperation(value = "Save a AttendedTest using POST method",notes = "Create test data ",response=Response.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> insert(@RequestBody AttendedTestBean attendTest)
	{
		List<AttendedTestBean> testList = new ArrayList<AttendedTestBean>();
		try{
			System.out.println();
			AttendedTestBean bean = attendTestDao.createAttendTest(attendTest);
			bean = attendTestDao.getAttendTestById(attendTest.getCommitId());
			testList.add(bean);
			saveMetaData(true, "AttendedTest Created", "12345");
			saveData(null, testList);
			error.setDescription(null);
			error.setCode(null);
			saveResponse(metaData, at_data, error);
			
		}
		catch(Exception e)
		{
			System.out.println("Exception occuredd");
			//e.printStackTrace();
			 if (e instanceof DataAccessException)
			   {
			error.setDescription("Database Error");
			   }
			 else{
				 error.setDescription(e.getMessage());
			 }
			error.setCode("12345");
			saveMetaData(false, "Book not created", "12345");
			saveResponse(metaData, null, error);
			return  new ResponseEntity<Response>(at_resp, HttpStatus.NOT_FOUND) ;
		}
		return  new ResponseEntity<Response>(at_resp, HttpStatus.OK) ;
	}
	
	
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of QuestionReports ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	@RequestMapping( value="/{commitId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getQuestionReports(@PathVariable String commitId) {
		ResponseEntity<Response> responseEntity=null;
		List<AttendedTestBean> beanList = new ArrayList<AttendedTestBean>();
		try{
		AttendedTestBean bean = attendTestDao.getAttendTestById(commitId);
		if(bean == null){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(metaData,null,error);
			return new ResponseEntity<Response>(at_resp, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			beanList.add(bean);
			saveMetaData(true,"Tests loaded","Success123");
			saveData(null, beanList);
			saveResponse(metaData, at_data, null);
			responseEntity= new  ResponseEntity<Response>(at_resp,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(metaData, null, error);
				responseEntity= new  ResponseEntity<Response>(at_resp,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }

	
	@ApiOperation(value = "Delete attendedTest using DELETE method",notes = "Delete attendedTest ",response=Response.class)
  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
  	  @RequestMapping(value = "del_comId/{commitId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
  	  public ResponseEntity<Response> DeleteAttendedTestByCid(@ApiParam(value="commitId whose attendedTest are to be deleted")@PathVariable("commitId") String commitId)
  	  {
		 List<AttendedTestBean> testBean = new ArrayList<AttendedTestBean>();  		  
		 try{
  			 
  			 int res = attendTestDao.deleteAttendedTestByCommitId(commitId);
  			  if(res != 1)
  			  {

  	  			error.setCode("Error001");
  	  			error.setDescription("Records with this cid is not found");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(metaData,null,error);
  	  			return new ResponseEntity<Response>(at_resp, HttpStatus.NOT_FOUND) ;
  			  }
  			  else if(res == 1)
  			  {
  					saveMetaData(true,"AttendedTest updated","Success123");
  		  			saveData(null, null);
  		  			saveResponse(metaData, at_data,null);
  		  			
  				}
  					
  		  }
  		  catch(Exception e){
  			  e.printStackTrace();
  				error.setCode("00005");
  				
  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
  					error.setDescription("Bad Request(Result size)");
  				else if( e instanceof DataAccessException)
  					error.setDescription("Database error");
  				else{
  					System.out.println("$$");
  					error.setDescription(e.getMessage());
  				}
  					saveMetaData(false,"Error Occured","e123");
  				
  				saveResponse(metaData, null,error);
  				System.out.println("Exception****"+e.getCause());
  				return new  ResponseEntity<Response>(at_resp,HttpStatus.CONFLICT);
  			}	
		 return new  ResponseEntity<Response>(at_resp,HttpStatus.OK);
        }	

	@ApiOperation(value = "Delete attendedTest using DELETE method",notes = "Delete attendedTest ",response=Response.class)
  	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
  	  @RequestMapping(value = "/{testId}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
  	  public ResponseEntity<Response> DeleteAttendedTest(@ApiParam(value="testId whose attendedTest are to be deleted")@PathVariable("testId") String testId)
  	  {
		 List<AttendedTestBean> testBean = new ArrayList<AttendedTestBean>();  		  
		 try{
  			 
  			 int res = attendTestDao.deleteAttendedTestByTestId(testId);
  			  if(res != 1)
  			  {

  	  			error.setCode("Error001");
  	  			error.setDescription("Records with this testid is not found");
  	  			
  	              saveMetaData(false,"Error Occured","12345");
  	  			
  	  			saveResponse(metaData,null,error);
  	  			return new ResponseEntity<Response>(at_resp, HttpStatus.NOT_FOUND) ;
  			  }
  			  else if(res == 1)
  			  {
  					saveMetaData(true,"AttendedTest updated","Success123");
  		  			saveData(null, null);
  		  			saveResponse(metaData, at_data,null);
  		  			
  				}
  					
  		  }
  		  catch(Exception e){
  			  e.printStackTrace();
  				error.setCode("00005");
  				
  				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
  					error.setDescription("Bad Request(Result size)");
  				else if( e instanceof DataAccessException)
  					error.setDescription("Database error");
  				else{
  					System.out.println("$$");
  					error.setDescription(e.getMessage());
  				}
  					saveMetaData(false,"Error Occured","e123");
  				
  				saveResponse(metaData, null,error);
  				System.out.println("Exception****"+e.getCause());
  				return new  ResponseEntity<Response>(at_resp,HttpStatus.CONFLICT);
  			}	
		 return new  ResponseEntity<Response>(at_resp,HttpStatus.OK);
        }	

	
private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(MetaData metaData, Data data, Error error) {
		at_resp.setData(data);
		at_resp.setMetaData(metaData);
		at_resp.setError(error);
	}
	private void saveData(Error erroDet, List testObj) {
		at_resp.setError(erroDet);
			at_data.setOutput(testObj);
	}

}
