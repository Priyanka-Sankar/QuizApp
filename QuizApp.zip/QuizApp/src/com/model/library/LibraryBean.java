package com.model.library;

import java.util.List;

import com.model.question.QuestionBean;

public class LibraryBean {
	
	String commitId;
	String category;
	String tag;
	List<QuestionBean> questions;
	String status;
	
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public List<QuestionBean> getQuestions() {
		return questions;
	}
	public void setQuestions(List<QuestionBean> questions) {
		this.questions = questions;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
}
