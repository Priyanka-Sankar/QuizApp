package com.model.library;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;



public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<LibraryBean> output;
	
	
	public List<LibraryBean>  getOutput() {
		return output;
	}
	public void setOutput(List<LibraryBean> outputList) {
		this.output = outputList;
	}
	
	
}
