package com.model.questionReport;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;



public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<QuestionReportBean> output;
	
	
	public List<QuestionReportBean>  getOutput() {
		return output;
	}
	public void setOutput(List<QuestionReportBean> outputList) {
		this.output = outputList;
	}
	
	
}
