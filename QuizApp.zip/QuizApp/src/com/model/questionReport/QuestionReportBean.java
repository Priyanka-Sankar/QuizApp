package com.model.questionReport;

import java.util.List;

public class QuestionReportBean {
	
	String testId;
	String commitId;
	String quesId;
	List<Integer> chosenAns;
	int score;
	public List<Integer> getChosenAns() {
		return chosenAns;
	}
	public void setChosenAns(List<Integer> chosenAns) {
		this.chosenAns = chosenAns;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public String getQuesId() {
		return quesId;
	}
	public void setQuesId(String quesId) {
		this.quesId = quesId;
	}
	
}
