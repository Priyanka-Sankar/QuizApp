package com.model.createdTest;
import io.swagger.annotations.ApiModelProperty;

import com.controller.Error;
import com.controller.MetaData;
public class Response {
	@ApiModelProperty(position =1, required = true, value = "data about data")
	private MetaData metaData;
	@ApiModelProperty(position = 2, required = true, value = "output of the operation")
	private Data data;
	@ApiModelProperty(position = 3, required = true, value = "Errors if any")
	private Error Error;
	public MetaData getMetaData() {
		return metaData;
	}
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public Error getError() {
		return Error;
	}
	public void setError(Error error) {
		Error = error;
	}

}
