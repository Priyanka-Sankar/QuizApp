package com.model.createdTest;

import java.util.List;

import com.model.question.QuestionBean;

public class CreatedTestBean {
	String commitId;
	String testId;
	String testName;
	int duration;
	int cutoff;
	String startTime;
	String expiryTime;
	List<QuestionBean> questions;
	int noQues;
	String status;
	String showMark;
	public String getShowMark() {
		return showMark;
	}
	public void setShowMark(String showMark) {
		this.showMark = showMark;
	}
	public String getShuffle() {
		return shuffle;
	}
	public void setShuffle(String shuffle) {
		this.shuffle = shuffle;
	}
	String shuffle;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getCutoff() {
		return cutoff;
	}
	public void setCutoff(int cutoff) {
		this.cutoff = cutoff;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getExpiryTime() {
		return expiryTime;
	}
	public void setExpiryTime(String expiryTime) {
		this.expiryTime = expiryTime;
	}
	public List<QuestionBean> getQuestions() {
		return questions;
	}
	public void setQuestions(List<QuestionBean> questions) {
		this.questions = questions;
	}
	public int getNoQues() {
		return noQues;
	}
	public void setNoQues(int noQues) {
		this.noQues = noQues;
	}
}
