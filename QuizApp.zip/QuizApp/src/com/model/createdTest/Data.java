package com.model.createdTest;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;



public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<CreatedTestBean> output;
	
	
	public List<CreatedTestBean>  getOutput() {
		return output;
	}
	public void setOutput(List<CreatedTestBean> outputList) {
		this.output = outputList;
	}
	
	
}
