package com.model.testReport;

public class TestReportBean {
	
	String testId;
	String commitId;
	int noOfCorrect;
	int totalScore;
	int rank;
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public int getNoOfCorrect() {
		return noOfCorrect;
	}
	public void setNoOfCorrect(int noOfCorrect) {
		this.noOfCorrect = noOfCorrect;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}

}
