package com.model.attendedTest;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;



public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<AttendedTestBean> output;
	
	
	public List<AttendedTestBean>  getOutput() {
		return output;
	}
	public void setOutput(List<AttendedTestBean> outputList) {
		this.output = outputList;
	}
	
	
}
