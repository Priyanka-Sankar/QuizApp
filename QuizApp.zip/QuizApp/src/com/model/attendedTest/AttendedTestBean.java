package com.model.attendedTest;

import java.util.List;
import java.util.Map;

import com.model.createdTest.CreatedTestBean;

public class AttendedTestBean {
	String commitId;
	Map<String,String> tests;
	
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public Map<String, String> getTests() {
		return tests;
	}
	public void setTests(Map<String, String> tests) {
		this.tests = tests;
	}

	
}
