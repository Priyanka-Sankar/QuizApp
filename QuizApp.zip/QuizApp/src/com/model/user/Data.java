package com.model.user;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;



public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<UserBean> output;
	
	
	public List<UserBean>  getOutput() {
		return output;
	}
	public void setOutput(List<UserBean> outputList) {
		this.output = outputList;
	}
	
	
}
