package com.model.question;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;



public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<QuestionBean> output;
	
	
	public List<QuestionBean>  getOutput() {
		return output;
	}
	public void setOutput(List<QuestionBean> outputList) {
		this.output = outputList;
	}
	
	
}
