export class QuestionReport{

    quesId:string;
    commitId:string;
    testId:string;
    chosenAns:number[];

}