export class Question{
    quesId:string;
    quesDesc:string;       
	options:Option[];
	answers:string[];
	difficulty:string;
	mark:number;
	 image:string;
	  category:string;
		tag:string;
		status:string="created";
	
	  

}
	
	class Option{
		desc:string;
		selected:boolean;
	}