export class TestReport {

    commitId: string;
    testId: string;
    testName: string;

    noOfQuestions: number;
    testMark: number;
    cutoff: number;
    noOfCorrect: number;
    totalScore: number;
    rank: number;






    // fail:boolean;
    percent: number;
    pass: boolean;
}