export class User{
    commitId : string;
    password : string;
    //emailId : string;
}