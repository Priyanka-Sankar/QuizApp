export class Question{
    quesId : string;
    quesDesc : string;
    options : string[];
    answers :string[];
    difficluty : string;
    mark : number;
    image : string;
}