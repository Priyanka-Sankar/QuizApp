import { Question } from './question';
export class Test{
    commitId : string;
    testId : string;
    testName : string;
    duration : number;
    cutoff : number;
    startTime : string;
    expiryTime : string;
    questions : Question[];
    noQues : number;
    status : string;
    showMark : boolean = false;
    shuffle : boolean = false;
}