import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Headers, RequestOptions } from '@angular/http';
import { User } from '../_models/user';
import { LoginService } from '../_services/login.service'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User = new User();
  users : User[];
  constructor(private router: Router, private loginService: LoginService) {
      localStorage.clear();
  }

  ngOnInit() {
   
  }

  validate() {
    if (this.user.commitId == undefined) {
      alert("commitId required");
      return false;
    }
    else if (this.user.password == undefined) {
      alert("password required");
      return false;
    }
    this.loginService.login(this.user)
      .subscribe(
      data => {
        // //this.user = data;

        // alert("hello"+data);
        // this.users = data['data']['output'];
        // alert(this.users[0].commitId);
        //alert(this.user.commitId);
        alert('Valid user');
        this.router.navigate(['/first']);
      },
      error => {
        alert("Invalid user");
      });
  }
}
