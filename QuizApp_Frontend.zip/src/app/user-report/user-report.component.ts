import { Component,OnInit } from '@angular/core';
import{Http} from '@angular/http';
import { TestReport } from '../_models/test-report'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ReportService } from '../_services/report.service';
import 'assets/js/add-chart.js';
@Component({
  selector: 'app-user-report',
  templateUrl: './user-report.component.html',
  styleUrls: ['./user-report.component.css']
})
export class UserReportComponent implements OnInit {
TestReports:TestReport[] =[];
    commitId:string;
    Result : any;
    chartRes:any;
    chartRes1:any;
    
    testDet:any;
    pass:boolean=false;
    fail:boolean=false;
    catScore:any=[];tScore:any=[];
    showChart:boolean=false;
    Chart:boolean=true;
    hideChart:boolean=false;
    constructor(private http: Http, private rservice: ReportService, private route: ActivatedRoute,
        private router: Router) {
        }

     ngOnInit() {
        this.route.params.subscribe(params => {
            this.commitId = params['cid'];
         
            this.getReports();
            
            this.getchart();
        });

       
    }
     getReports()
        {
             this.rservice.getByCommitId(this.commitId).subscribe(data =>{
                 this.Result=data['data']['output'];
                 this.TestReports=[];
                 for(let i=0;i<this.Result.length;i++)
                    {
                          this.showChart=true;
                      
                         this.rservice.getTestDetails(this.Result[i].testId).subscribe(d=>{


                            this.testDet=d['data']['output'][0];
                            let mark=0;
                            let percent;
                            for(let h=0;h<this.testDet.noQues;h++)
                                {

                                    mark+=this.testDet['questions'][h].mark;
                                   // this.catScore.push({category:this.testDet['questions'][h].category,score:});
                                }
                               if( this.Result[i].totalScore>=this.testDet.cutoff)
                                this.pass=true;
                               else
                                this.fail=true;
                               percent=(this.Result[i].totalScore/mark)*100;
                            this.TestReports.push(
                            {
                              testId:this.Result[i].testId ,
                              commitId:this.Result[i].commitId,
                              noOfCorrect:this.Result[i].noOfCorrect,
                              totalScore:this.Result[i].totalScore,
                              rank:this.Result[i].rank,
                              testName:this.testDet.testName,
                              noOfQuestions:this.testDet.noQues,
                                mark:mark,
                                cutoff:this.testDet.cutoff,
                                fail:this.fail,
                                pass:this.pass,
                                percent:percent
                            }
                            
                            
                        );
                     
                               
                        mark=0;
                         this.pass=false;
                          this.fail=false;
                         });
                        
                        
                    }
             }); 
               
                console.log(this.TestReports.length);
               
        }
            getchart()
            {

                this.rservice.getCatScore(this.commitId).subscribe(data=>{
            
                this.chartRes=data['data']['output'];
                 let array=['category','score'];
                  this.catScore.push(array);
                for(let i=0;i<this.chartRes.length;i++){

                   
                    let key=Object.keys(this.chartRes[i]);
                    console.log(key);
                    for(let j=0;j<key.length;j++)
                        {
                             let array:any=[];
                    array.push(key[j],this.chartRes[i][key[j]]);
                    
                    this.catScore.push(array);
                        }
                }
               localStorage.setItem('catScore',this.catScore);

            
            });
             this.rservice.gettScore(this.commitId).subscribe(data=>{
            
                this.chartRes1=data['data']['output'];
                 let array=['commitId','score'];
                  this.tScore.push(array);
                  
                for(let i=0;i<this.chartRes1.length;i++){

                   
                    let key=Object.keys(this.chartRes1[i]);
                   // console.log(key);
                   let length;
                  if(key.length<=5)
                    {

                        length=5;
                    }
                    else
                        {
                            length=key.length;
                        }
                    for(let j=0;j<length;j++)
                        {
                             let array:any=[];
                    array.push(key[j],this.chartRes1[i][key[j]]);
                    
                    this.tScore.push(array);
                        }
                }
               localStorage.setItem('tScore',this.tScore);

            
            });
            
           // console.log( localStorage.getItem('catScore')[0]);
            }
        shChart(){
           
            this.hideChart=true;
            this.showChart=false;
            
            
        }
        hdChart(){
           
            this.hideChart=false;
            this.showChart=true;
            
        }
        show()
        {
            if( this.showChart==false)
                return "block";
            else
                return "none";
        }
          overallReport(){
            this.router.navigate(['overall',localStorage.getItem('currentUser')]);
          }
}
