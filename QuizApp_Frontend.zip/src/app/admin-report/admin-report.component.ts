import { Component,OnInit } from '@angular/core';
import{Http} from '@angular/http';
import { TestReport } from '../_models/test-report'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ReportService } from '../_services/report.service';

@Component({
  selector: 'app-admin-report',
  templateUrl: './admin-report.component.html',
  styleUrls: ['./admin-report.component.css']
})
export class AdminReportComponent implements OnInit {

  commitId:string;
    tests:any;
    testId:string[]=[];
 ngOnInit() {
console.log('adminreport ninit');
this.tests=[];
this.getAllTests();

 }
 constructor(private http: Http, private rservice: ReportService, private route: ActivatedRoute,
        private router: Router) {
            
        }
 getAllTests()
 {

    console.log('get all tests');
    this.commitId=localStorage.getItem('currentUser');
  //this.commitId='XBBNHBG';
  this.rservice.getCreatedTests(this.commitId).subscribe(data=>{console.log('hi');console.log(data);

    this.tests=data['data']['output'];
    for(let t=0;t<this.tests.length;t++)
        {
            this.testId[t]=this.tests[t].testId;
        }
                                
  });
  

 }

getReport(tid:string)
{
    this.router.navigate(['nav/sideReport/get',tid]);
}

}
