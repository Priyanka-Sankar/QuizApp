import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './_services/login.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  clicked : boolean = false;

  imgSrc:string;
  imgchk:string;
  errImg:string;

  constructor(private loginService:LoginService,private router:Router){
this.errImg='assets/images/logo-lg.png';
  }
  ngOnInit(){
  //  localStorage.clear();
  }
  isRouted()
  {
    if(localStorage.getItem("currentUser")){
        this.clicked = true;
 this.imgSrc="https://mysourcesocial.bnymellon.net/people/"+localStorage.getItem("currentUser")+"/avatar/128.png";
    }
  }
  logout(){
     localStorage.removeItem("ticks");
     console.log('inside');
    this.loginService.logout();
   this.router.navigate(['/']);

  }
}
