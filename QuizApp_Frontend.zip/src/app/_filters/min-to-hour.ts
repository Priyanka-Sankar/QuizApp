import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name : 'toHour'})
export class MinuteToHour implements PipeTransform{
    transform(value:number)
    {
        
        let hr = Math.floor(value/60)+ " Hour ";
        let rem = value%60;
        if(rem != 0)
            hr+=""+rem+" Minutes";
        else
            hr+='00 Minutes';
        return hr;
    }
}