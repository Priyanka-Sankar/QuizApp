import {Component,Pipe,PipeTransform} from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {
  transform(components: any[], args: any): any {
    var val = args[0];
    var lowerEnabled = args.length>1 ? args[1] : false;

    // filter components array, components which match and return true will be kept, false will be filtered out
    return components.filter((component)=> {
      if (lowerEnabled) {
        if(component.name.toLowerCase())
        return (component.name.toLowerCase().indexOf(val.toLowerCase())!== -1);
      } else {
        if(component.name)
        return (component.name.indexOf(val)!== -1);
      }
    });
    //return components;
  }
}