import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Question } from '../_models/question.1'
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { QuestionService } from '../_services/question.service';
import { ActivatedRoute, Router } from '@angular/router';
import 'assets/js/add-options.js';

@Component({
  selector: 'app-edit-question',
  templateUrl: './edit-question.component.html',
  styleUrls: ['./edit-question.component.css']
})
export class EditQuestionComponent {

  Question: Question = new Question();
    Result: any;
    
    difTouched: boolean = false;
    markTouched: boolean = false;
    descTouched: boolean = false;
    answerTouched:boolean=false;
    time: Date;
    image: string;
    message: string = "Please wait..";
    ngOnInit() {
        this.route.params.subscribe(params => {
            this.Question.quesId = params['id'];
         
            this.getQuestions();
        });
    }
    constructor(private http: Http, private qservice: QuestionService, private route: ActivatedRoute,
        private router: Router) {
        this.Question.options = [];
       this.Question.answers = [];
        this.Question.difficulty = "Select Difficulty";
        //this.ans.push(true);

    }
    clickCk(event: any) {

        this.answerTouched=true;
        //this.ans.map((itemInArray) => itemInArray);
        //alert(this.Question.answers.some(a=>a==event.target.getAttribute('value')));
        
        if (event.target.getAttribute('value') != "") {
            console.log("value"+event.target.getAttribute('value'));
            if ((!this.Question.answers.some(a => a == event.target.getAttribute('value')))) {
                this.Question.answers.push(event.target.getAttribute('value'));

            }
            else{
  let index=this.Question.answers.indexOf(event.target.getAttribute('value'));
  this.Question.answers.splice(index,1);
}
        }
        console.log(this.Question.answers);
    }
    getQuestions() {

        this.qservice.getByQuestionId(this.Question.quesId).subscribe(data => {
            this.Result = data['data']['output'];
            this.Question.quesDesc = this.Result[0]['quesDesc'];
            let options = this.Result[0]['options'];
            let answers = this.Result[0]['answers'];

           
            for (let i = 0; i < options.length; i++) {
 let selected = false;
                if (answers.indexOf(i) >= 0) {
                    selected = true;
                }
               console.log(answers.indexOf(i));
                this.Question.options.push({ desc: options[i], selected: selected });
            }

            for(let i = 0; i < answers.length; i++) {
                 this.Question.answers.push(answers[i]+"");
            }
           
            this.Question.difficulty = this.Result[0]['difficulty'];
            this.Question.mark = this.Result[0]['mark'];
            this.image = this.Result[0]['image'];
            console.log('d'+this.Question.answers);




        });

    }
    chgimg()
    {
        this.image=localStorage.getItem('image');
    }
    desc_touched() {

        this.descTouched = true;
    }
    d_odisp() {
        if (this.descTouched) {
           

            if (this.Question.quesDesc == "" || this.Question.quesDesc == undefined) {

                return "none";
            }
            else {

                return "block";
            }
        }
        else {

            return "none";
        }

    }
    d_wdisp() {
        if (this.descTouched) {

            if (this.Question.quesDesc == "" || this.Question.quesDesc == undefined) {

                return "block";
            }
            else {

                return "none";
            }
        }
        else {

            return "none";
        }
    }
    aodisp() {
        console.log(this.Question.answers.length);
        if (this.Question.answers.length > 0) {

            return "block";
        }
        else {

            return "none";
        }

    }
    awdisp() {

        if (this.Question.answers.length > 0) {

            return "none";
        }
        else {

            return "block";
        }
    }
    dif_touched() {
        this.difTouched = true;
    }
    dodisp() {
        if (this.difTouched) {
            if (this.Question.difficulty != undefined) {

                if (this.Question.difficulty != "Select Difficulty") {

                    return "block";
                }
                else {

                    return "none";
                }
            }
            else {

                return "none";
            }
        }
        else {

            return "none";
        }

    }
    dwdisp() {
        if (this.difTouched) {
            if (this.Question.difficulty == undefined) {

                return "block";
            }
            if (this.Question.difficulty == "Select Difficulty") {

                return "block";
            }
            else {

                return "none";
            }
        }
        else {

            return "none";
        }
    }
    mark_touched() {
        this.markTouched = true;
    }
    modisp() {
        if (this.markTouched) {
            if (this.Question.mark != undefined && this.Question.mark > 0) {

                return "block";
            }
            else {

                return "none";
            }
        }
        else {

            return "none";
        }

    }
    mwdisp() {
        if (this.markTouched) {
            if (this.Question.mark != undefined && this.Question.mark > 0) {

                return "none";
            }
            else {

                return "block";
            }
        }
        else {

            return "none";
        }
    }
incOpt(){
   //alert(this.Question.options[0].desc);

 this.Question.options.push({desc:"",selected:false});
 //this.ans.push(true);
 //for ( var i=0;i<this.Question.options.length;i++)
 //alert(this.Question.options[i].desc);
 

  
}
decOpt(){
    let last=this.Question.options.length-1;
    let index=this.Question.answers.indexOf(last+"");
    console.log('last'+last+'in'+index);
    if(index!=-1)
  this.Question.answers.splice(index,1);
this.Question.options.pop();
 //for ( var i=0;i<this.Question.options.length;i++)
 //alert(this.Question.options[i].desc);
 
}
    call() {

        console.log(this.Question.quesId);
        let error:any;
        if (this.descTouched) {
            if (this.d_odisp() == "block") {
                console.log(this.Question.quesDesc);
                let q={"quesId":this.Question.quesId,"quesDesc":this.Question.quesDesc};
                this.qservice.update("description", q).subscribe(data => { this.message = data['metaData']['description'] });
               
            }
            else
                {
                    error=1;
                this.message = "Check field with 'X' symbol..";
                }
        }
        if (this.difTouched) {
            if (this.dodisp() == "block") {
                console.log(this.Question.difficulty);
                 let q={"quesId":this.Question.quesId,"difficulty":this.Question.difficulty};
                this.qservice.update("difficulty", q).subscribe(data => { this.message = data['metaData']['description'] });
            }
            else {
                error=1;
                this.message = "Check field with 'X' symbol..";
            }
        }
        if (this.markTouched) {
            if (this.modisp() == "block") {
                console.log(this.Question.mark);
                let q={"quesId":this.Question.quesId,"mark":this.Question.mark};
                this.qservice.update("mark", q).subscribe(data => { this.message = data['metaData']['description'];
                        console.log(data);
            
            });
            }
            else {
                error=1;
                this.message = "Check field with 'X' symbol..";
            }

        }
        if (this.answerTouched) {
            if (this.aodisp() == "block") {
               
                this.Question.answers=this.Question.answers.sort();
                let q={"quesId":this.Question.quesId,"answers":this.Question.answers};
                this.qservice.update("answers", q).subscribe(data => { this.message = data['metaData']['description'] });
                console.log('beddage:'+this.message);
            }
            else {
                error=1;
                this.message = "Check field with 'X' symbol..";
            }

        }
        console.log(this.Question.options);
         let i;
         let options:any=[];
    for(i=0;i<this.Question.options.length;i++)
      {
           options.push(this.Question.options[i].desc);
      }
        let qo={"quesId":this.Question.quesId,"options":options};
        this.qservice.update("options",qo).subscribe(data => { this.message = data['metaData']['description'] });
        let q={"quesId":this.Question.quesId,"image":localStorage.getItem('image')};
        this.qservice.update("image",q).subscribe(data => { this.message = data['metaData']['description'] });
        if(error!=1)
            {
                this.message = "Question Updated";
                this.router.navigate(['nav/sideLibrary']);
            }


        


    }
}
