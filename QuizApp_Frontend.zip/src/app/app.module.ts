//Modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


//Components
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FirstComponent } from './first/first.component';
import { NavComponent } from './nav/nav.component';
import { SideComponent } from './side/side.component';
import { TestComponent } from './test/test.component'
import { SideLibraryComponent } from './side-library/side-library.component';
import { SideReportComponent } from './side-report/side-report.component';
import { DeleteDialogComponent } from './delete-dialog/delete-dialog.component';
import { EditDialogComponent } from './edit-dialog/edit-dialog.component';

//Services
import { LoginService } from './_services/login.service';
import { TestService } from './_services/test.service';
import { TestStorageService } from './_services/test-storage.service';
import { QuestionService } from './_services/question.service';
import { ReportService } from './_services/report.service';
import { PagerService } from './_services/pager.service'
import { DatePipe } from '@angular/common';

//Guards
import { AuthGuard } from './_guards/auth.guard';

//Filters
import { MinuteToHour } from './_filters/min-to-hour';
import { SearchPipe } from './_filters/search';
import { AllQuestionsComponent } from './all-questions/all-questions.component';
import { NewQuestionComponent } from './new-question/new-question.component';
import { EditQuestionComponent } from './edit-question/edit-question.component';
import { AdminReportComponent } from './admin-report/admin-report.component';
import { DisplayReportComponent } from './display-report/display-report.component';
import { TakeuptestComponent } from './takeuptest/takeuptest.component';
import { ListtestComponent } from './listtest/listtest.component';
import { UserReportComponent } from './user-report/user-report.component';
import { TimerComponent } from './timer/timer.component';

// canActivate: [AuthGuard]
const appRoutes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'first', component: FirstComponent, canActivate: [AuthGuard] },
  {
    path: 'nav', component: NavComponent, canActivate: [AuthGuard],
    children: [
      {
        path: 'side', component: SideComponent,
        children: [
          { path: 'test', component: TestComponent },

        ]
      },
      {
        path: 'sideLibrary', component: SideLibraryComponent,
        children: [
          { path: 'allquestions', component: AllQuestionsComponent },
          { path: 'edit/:id', component: EditQuestionComponent }
        ]
      },
      {
        path: 'sideReport', component: SideReportComponent,
        children: [
          { path: 'reports', component: AdminReportComponent },
          { path: 'get/:tid', component: DisplayReportComponent }
        ]
      }
    ]
  },
  { path: 'listtest', component: ListtestComponent ,canActivate: [AuthGuard]},
  { path: 'takequiz/:id', component: TakeuptestComponent, canActivate: [AuthGuard] },
  { path: 'overall/:cid',component:UserReportComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: 'first', canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [
    //Components
    AppComponent,
    LoginComponent,
    FirstComponent,
    NavComponent,
    SideComponent,
    TestComponent,
    SideLibraryComponent,
    SideReportComponent,
    DeleteDialogComponent,
    EditDialogComponent,
    AllQuestionsComponent,
    //Filters
    MinuteToHour,
    SearchPipe,
    NewQuestionComponent,
    EditQuestionComponent,
    AdminReportComponent,
    DisplayReportComponent,
    UserReportComponent,
TakeuptestComponent,
ListtestComponent,
TimerComponent,


  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    HttpModule,
    ModalModule.forRoot(),
    BootstrapModalModule
  ],
  providers: [
    LoginService,
    TestService,
    QuestionService,
    TestStorageService,
    ReportService,
    DatePipe,
    AuthGuard,
    PagerService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
