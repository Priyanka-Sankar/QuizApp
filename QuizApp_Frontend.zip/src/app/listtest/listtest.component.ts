import { Component, ViewContainerRef, OnInit,Pipe, PipeTransform } from '@angular/core';
import { Test } from '../_models/tests';
import { Router } from '@angular/router';
import { TestService } from '../_services/test.service';
import { MinuteToHour } from '../_filters/min-to-hour';
import 'assets/js/sidetab.js';
import {DatePipe } from '@angular/common';
 
// import 'assets/js/add-options.js';

@Component({
  selector: 'app-listtest',
  templateUrl: './listtest.component.html',
  styleUrls: ['./listtest.component.css']
})

export class ListtestComponent implements OnInit {
 testBean: Test[];
 filteredTBean:Test[]=[];
  filteredTest : Test[];
  testToEdit: Test = new Test();
  toDelete: string;
  show : boolean;
  showFilter : boolean;
  noData : boolean;
  flag = new Boolean()[9];
  success: boolean[];
  inputText: string;
  testShowDialog = false;
  editShowDialog = false;
  delShowDialog = false;
  message : string;
  showTakeTest:boolean=true;
  currentdate:any;
  ctime:any;
  dbtime:any;
  latest_date:any;
  user:any;
  constructor(private router: Router, private testService: TestService,private datepipe:DatePipe) { 
       this.flag = [];
    this.filteredTest = [];
    
    for (let i = 0; i < 7; i++)
      this.flag[i] = false;
    this.success = [];
    for (let i = 0; i < 7; i++)
      this.success[i] = false;
  
  }

  ngOnInit() {
   // console.log('ngoninitttttt');
    this.show = false;
    this.showFilter = false;
    this.noData = false;
    this.inputText = '';
  this.user=localStorage.getItem("currentUser");

this.testService.getAvailableTest(this.user).
      subscribe(data => {
        this.testBean = data['data']['output'];
        if(this.testBean.length == 0){
        this.noData = true;
        this.show = false;

      }
      else{
        this.checkDate(this.testBean);
        this.show = true;
        this.noData = false;
      }
      });
  }
checkDate(testBeanchk:Test[])
{
  this.ctime = new Date();
  
  this.latest_date = this.datepipe.transform(this.ctime, 'yyyy-MM-ddTHH:mm');

  let j=0;
     for(let i=0;i<testBeanchk.length;i++)
      {  
       // console.log(testBeanchk);
        this.dbtime=new Date(testBeanchk[i]['expiryTime']);
        this.dbtime=this.datepipe.transform(this.dbtime, 'yyyy-MM-ddTHH:mm');
        let check=0;
        this.testService.checkTest(this.user,testBeanchk[i].testId).subscribe(data=>{
         check= data['data']['output'][0];
         console.log("checjjjj"+check+"tetsNme"+testBeanchk[i].testName);
        if((this.dbtime.localeCompare(this.latest_date)>0) && check==1 )
          { 
            
            this.filteredTBean[j]=new Test();
            this.filteredTBean[j].commitId=testBeanchk[i].commitId;
            this.filteredTBean[j].cutoff=testBeanchk[i].cutoff;
            this.filteredTBean[j].duration=testBeanchk[i].duration;
            this.filteredTBean[j].expiryTime=testBeanchk[i].expiryTime;
            this.filteredTBean[j].noQues=testBeanchk[i].noQues;
            this.filteredTBean[j].questions=testBeanchk[i].questions;
            this.filteredTBean[j].startTime=testBeanchk[i].startTime;
            this.filteredTBean[j].status=testBeanchk[i].status;
            this.filteredTBean[j].testId=testBeanchk[i].testId;
            this.filteredTBean[j].testName=testBeanchk[i].testName;
            j++;
          }
           check=0;
        //  this.filteredTBean[i].

          

});          

      
}
}
  navigate(id:string)
  {
  let windowObjectReference;

    windowObjectReference = window.open(
      '/takequiz/'+id,
      // first param is location
      ///<string>this._router.navigate(['Feature']),
      // this.router.navigate(['/takequiz',id]),
      'DescriptiveWindowName',
      'width=700,height=700,resizable,scrollbars=yes,status=0,toolbar=0,menubar=0,location=0'
    
    );
    
    this.showTakeTest=false;
    // this.router.navigate(['/takequiz',id]);
  }

  


filterOnSearch() {
    this.show = false;
    this.noData = false;
    this.filteredTest = [];
    for(let i = 0;i<this.filteredTBean.length;i++)
      {
        if(this.testBean[i].testName.toLowerCase().indexOf(this.inputText.toLowerCase()) != -1)
          this.filteredTest.push(this.testBean[i]);
      }
      this.showFilter = true;
      if(this.filteredTest.length == 0)
        {
          this.noData = true;
          this.show = false;
          this.showFilter = false;
        }
  }
overallReport(){
  this.router.navigate(['overall',localStorage.getItem('currentUser')]);
}
}
