import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../_services/question.service';
import { Question } from '../_models/question';
import { Router, ActivatedRoute } from '@angular/router';
import { Test } from '../_models/tests';
import { TestService } from '../_services/test.service';
import { TestStorageService } from '../_services/test-storage.service';
import { DatePipe } from '@angular/common';

import 'assets/js/sidetab.js';
import 'assets/js/add-options.js';
@Component({
  selector: 'app-all-questions',
  templateUrl: './all-questions.component.html',
  styleUrls: ['./all-questions.component.css'],

})
export class AllQuestionsComponent implements OnInit {

  questions: any[];
  dispCreate:boolean = true;
  testToInsert: Test = new Test();
  tableDisplay: boolean;
  newQues: boolean;
  ctestFlag: boolean = false;
  isEdit: boolean;
  quesToInsert: string[] = [];
  availTests: Test[];
  time: Date;
  flag = false;
  constructor(private router: Router, private datePipe: DatePipe, private route: ActivatedRoute, private quesService: QuestionService, private testService: TestService, private storageService: TestStorageService) {
    this.questions = [];



  }

  ngOnInit() {
    // localStorage.getItem('commitId');
    if (this.router.url.indexOf('?') >= 0) {
      this.ctestFlag = true;
      let params = this.router.url.substr((this.router.url.indexOf('?') + 1));
      if (params.indexOf('&') >= 0) {
        let any = params.split('&');
        for (let i = 0; i < any.length; i++) {
          let temp = any[i].split('=');
          if (temp[1] == 'on') {
            this.testToInsert[temp[0]] = true;
          }
          else if (temp[0] == 'duration' || temp[0] == 'cutoff')
            this.testToInsert[temp[0]] = parseInt(temp[1]);
          else
            this.testToInsert[temp[0]] = temp[1];

        }
        this.time = new Date();
        let latest_date = this.datePipe.transform(this.time, 'yyyy-MM-ddTHH:mm');
        this.testToInsert.testId = "t" + localStorage.getItem("currentUser") + latest_date;
        this.testToInsert.noQues = 0;
        this.testToInsert.status = "created";
        this.testToInsert.commitId = localStorage.getItem('currentUser');
        this.testToInsert.testName = this.testToInsert.testName.replace('%2B', ' ');
        this.testToInsert.questions = [];
      }
    }
    // console.log(this.testToInsert.testName);
    this.tableDisplay = true;
    this.newQues = false;
    this.isEdit = false;
this.dispCreate = true;
    this.quesService.getAllQuestions(localStorage.getItem('currentUser'), 'created').
      subscribe(data => {
        let size = data['data']['output'].length;
        for (let i = 0; i < size; i++) {
          this.questions[i] = new Question();
          this.questions[i] = data['data']['output'][i];
          //console.log(this.questions[i]);
        }
      }
      );
    if (!this.ctestFlag) {
      this.dispCreate = true;
      this.testService.getByCommitId(localStorage.getItem('currentUser')).
        subscribe(data => {
          this.availTests = data['data']['output'];
        })
    }
    else {
      this.dispCreate = false;
      this.availTests = [];
      console.log(this.testToInsert);
      this.availTests.push(this.testToInsert);
    }
  }
  checkAns(answers: any[], index: number) {
    if (answers.indexOf(index) >= 0)
      return true;
    return false;
  }

  preventEdit() {
    return false;
  }
  callNewQues() {
    this.newQues = true;
    this.tableDisplay = false;
    this.dispCreate  = false;
  }
  editQues(quesId: string) {
    console.log(this.router.url);
    this.isEdit = true;
    this.newQues = false;
    this.tableDisplay = false;
    this.dispCreate  = false;

    this.router.navigate(['/nav/sideLibrary/edit', quesId]);
  }
  checkedQues(quesId: string) {
    if ((!this.quesToInsert.some(a => a == quesId))) {
      this.quesToInsert.push(quesId)

    }

    else {
      let index = this.quesToInsert.indexOf(quesId);
      this.quesToInsert.splice(index, 1);
    }
    console.log(this.quesToInsert);
  }
  addQuesToTest(testId: string) {
    this.flag = true;
    console.log("called here");
    if (!this.ctestFlag) {
      this.testService.addQuesToTest(testId, this.quesToInsert).
        subscribe(data => console.log(data));
    }
    else {
      this.testToInsert.noQues = this.quesToInsert.length;
      this.testToInsert.questions = [];
      // console.log(this.questions);
      //console.log(this.questions);
      for (let i = 0; i < this.questions.length; i++) {

        // console.log('Question bean');
        for (let j = 0; j < this.questions[i].questions.length; j++) {
          if (this.quesToInsert.indexOf(this.questions[i]['questions'][j]['quesId']) >= 0) {
            //console.log(this.questions[i]['questions'][j]['quesId']);
            this.testToInsert.questions.push(this.questions[i]['questions'][j]);
          }

        }
      }
      console.log(this.testToInsert);
      this.testService.addNewTest(this.testToInsert).
        subscribe(data => {
          console.log(data);
          alert(data['metaData']['description']);
        }


        );
    }
  }
delQues(quesId:string){
  this.quesService.deleteQues(quesId).subscribe(data=>{
    alert('Question removed');
  })
}
 
}