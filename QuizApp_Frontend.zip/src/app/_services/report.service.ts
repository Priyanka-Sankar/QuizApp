import { Injectable } from '@angular/core';
import { Http,Headers,Response,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { TestReport } from '../_models/test-report';
import { QuestionReport } from '../_models/question-report';
import 'rxjs/add/operator/map'
const BASE_URL = 'http://172.24.34.250:8080/QuizApp/testReports/';
const testUrl='http://172.24.34.250:8080/QuizApp/createdTest/testId/';
const ctestUrl='http://172.24.34.250:8080/QuizApp/createdTest/';
const questionReport='http://172.24.34.250:8080/QuizApp/questionReport/';
@Injectable()
export class ReportService{


  constructor(private http :  Http) {

   }


   getCreatedTests(commitId:string):Observable<any>
   {
       console.log('get created test service');
       return this.http.get(ctestUrl+commitId).map(response=>response.json());
   }
   getByCommitId(commitId:String):Observable<any>
  {
    return this.http.get(BASE_URL+commitId).map(response => response.json());
  }
 getBytId(tId:String):Observable<any>
  {
    return this.http.get(BASE_URL+'test/'+tId).map(response => response.json());
  }

  getTestDetails(testId:string):Observable<any>
  {
 return this.http.get(testUrl+testId).map(response => response.json());

  }
   getCatScore(commitId:String):Observable<any>
   {

    let url=questionReport+'catScore/'+commitId;
    console.log(url);
    return this.http.get(url).map(response=>response.json());
   }
gettScore(commitId:String):Observable<any>
   {

    let url=questionReport+'tScore';
    console.log(url);
    return this.http.get(url).map(response=>response.json());
   }
   insertQuesReport(report : QuestionReport):Observable<any>
    {
        return this.http.post(questionReport,report).map(response=>response.json());

    }
    insertTestReport(report: TestReport):Observable<any>
    {
        return this.http.post(BASE_URL,report).map(response=>response.json());
        
    }
    
}