import { Injectable } from '@angular/core';
import { Http,Headers,Response,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Test } from '../_models/tests'
import 'rxjs/add/operator/map'

const BASE_URL = 'http://172.24.34.250:8080/QuizApp/';


@Injectable()
export class QuestionService {

  constructor(private http :  Http) { }

  getAllQuestions(commitId:string, status:string){
      return this.http.post(BASE_URL+'library/commitId_status',{
            commitId : commitId,
            status : status
      }).map(response => response.json());
  }
    getByQuestionId(quesId : string):Observable<any>
  {
    console.log('inside Quess'+quesId)
    return this.http.get(BASE_URL+'questions/'+quesId).map(response => response.json());
  }
   update(whatTo:string,Question:any):Observable<any>
   {
       console.log(Question.quesId);
       return this.http.put(BASE_URL+'questions/'+whatTo,Question).map(response=>response.json());
   }
      deleteQues(quesId:string){
        return this.http.delete(BASE_URL+'questions/'+quesId).map(response=>response.json());
      }
}