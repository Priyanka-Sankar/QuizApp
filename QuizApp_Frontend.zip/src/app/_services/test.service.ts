import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Test } from '../_models/tests';
import { Question } from '../_models/question';
import 'rxjs/add/operator/map'

const BASE_URL = 'http://172.24.34.250:8080/QuizApp/createdTest/';
const testRep="http://172.24.34.250:8080/QuizApp/testReports/check";


@Injectable()
export class TestService {
  test: Test;
  constructor(private http: Http) { }

  getByCommitId(commitId: string) {
    return this.http.get(BASE_URL + commitId).map(response => response.json());
  }
getQuestionByTestId(testId:string)
{
return this.http.get(BASE_URL+'testId/'+testId).map(response=>response.json());

}

  getTestByTestId(testId : string){
      return this.http.get(BASE_URL +'testId/'+ testId).map(response => response.json());
  }
 
  getAvailableTest(commitId:string){
    return this.http.get(BASE_URL+'all/'+commitId).map(response=>response.json());
  }
  checkTest(commitId:string, testId:string){
    return this.http.post(testRep,{commitId:commitId, testId:testId}).map(response=>response.json());
  }
  addNewTest(test : Test){
    return this.http.post(BASE_URL, test).map(response => response.json());
  }
  addQuesToTest(testId: string, question: string[]) {
    
    let ques: Question[] = [];
    for (let i = 0; i < question.length; i++) {
      ques[i] = new Question();
      ques[i].quesId = question[i];

    }
   
   
    let bean = { testId: testId, questions: ques };
  
    return this.http.put(BASE_URL, bean).map(response => response.json());
  }
  deleteByTestId(testId: string) {
    return this.http.delete(BASE_URL + testId).map(response => response.json());
  }
  editTestName(testBean: Test) {
    return this.http.put(BASE_URL + 'testName', { testId: testBean.testId, testName: testBean.testName }).map(response => response.json());
  }
  editTestDuration(testBean: Test) {
    return this.http.put(BASE_URL + 'duration', { testId: testBean.testId, duration: testBean.duration }).map(response => response.json());
  }
  editTestCutoff(testBean: Test) {
    return this.http.put(BASE_URL + 'cutoff', { testId: testBean.testId, cutoff: testBean.cutoff }).map(response => response.json());
  }
  editTestShowMark(testBean: Test) {
    return this.http.put(BASE_URL + 'showMark', { testId: testBean.testId, showMark: '' + testBean.showMark }).map(response => response.json());
  }
  editTestShuffle(testBean: Test) {
    return this.http.put(BASE_URL + 'shuffle', { testId: testBean.testId, shuffle: '' + testBean.shuffle }).map(response => response.json());
  }
  editStartTime(testBean: Test) {
    return this.http.put(BASE_URL + 'startTime', { testId: testBean.testId, startTime: '' + testBean.startTime }).map(response => response.json());
  }
  editEndTime(testBean: Test) {
    return this.http.put(BASE_URL + 'endTime', { testId: testBean.testId, expiryTime: '' + testBean.expiryTime }).map(response => response.json());
  }
  removeQuesFromTest(testId:string, quesId:string){
    let ques:Question = new Question();
    let question: Question[] = [];
    
    ques.quesId = quesId;
    question.push(ques);

    let test = new Test();
    test.testId = testId;
    test.questions = question;
   
   
    return this.http.put(BASE_URL+'del',test).map(response => response.json());
  }

  
}
