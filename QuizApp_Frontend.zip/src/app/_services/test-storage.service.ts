import { Injectable } from '@angular/core';
import { Test } from '../_models/tests';


@Injectable()
export class TestStorageService {
  test : Test;
  getTest(): Promise<Test> {
    return Promise.resolve(this.test);
  }

  setTest(test : Test){
    this.test = test;
  }
}
