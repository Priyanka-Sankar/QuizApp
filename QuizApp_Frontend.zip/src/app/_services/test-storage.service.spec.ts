import { TestBed, inject } from '@angular/core/testing';

import { TestStorageService } from './test-storage.service';

describe('TestStorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TestStorageService]
    });
  });

  it('should be created', inject([TestStorageService], (service: TestStorageService) => {
    expect(service).toBeTruthy();
  }));
});
