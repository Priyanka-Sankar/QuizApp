import { Injectable } from '@angular/core';
import { User } from '../_models/user';
import { Http,Headers,Response,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

const BASE_URL = 'http://172.24.34.250:8080/QuizApp/users/';

@Injectable()
export class LoginService {

ngOnInit(){
    
}
  constructor(private http : Http) {
       
   }

  login(userBean:User) {
    //   const headers: Headers = new Headers();
    // headers.append('Accept', 'application/json');
    // headers.append('Content-Type', 'application/json');
    // headers.append('Access-Control-Allow-Origin', '*');
    // headers.append('body', '');
    // const options = new RequestOptions({
    //   headers: headers
    // });
   return this.http.post(BASE_URL, userBean)
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let user = response.json();
                console.log(user.token);
                if (user) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', userBean.commitId);
                    //console.log(localStorage.getItem('currentUser'));
                }
            });
  }

  logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
}
