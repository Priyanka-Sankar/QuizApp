import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Question } from '../_models/question.1'
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'assets/js/add-options.js';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-new-question',
  templateUrl: './new-question.component.html',
  styleUrls: ['./new-question.component.css'],

})
export class NewQuestionComponent {
  Question: Question = new Question();
  cat_touched: boolean = false;
  tagTouched: boolean = false;
  difTouched: boolean = false;
  markTouched: boolean = false;
  descTouched: boolean = false;
  tags: string[];
  othercat: string;
  othertag: string;
  answers: number[] = [];
  javaTags: string[] = ["Spring", "Maven", "REST"];
  sqlTags: string[] = ["DDL", "DML"];
  angularTags: string[] = ["Roting", "services"];
  category: string;
  options: string[] = [];
  tag: string;
  time: Date;
  //reg:RegExp;
  message: string = "Please wait..";
  constructor(private http: Http, public datepipe: DatePipe, private router:Router) {
    this.Question.options = [{ desc: "Option_A", selected: false }];
    this.Question.answers = [];
    this.tags = [];
    this.othercat = "";
    this.othertag = "";
    this.Question.category = "Select Category";
    this.Question.tag = "Select Tag";
    this.Question.difficulty = "Select Difficulty";

    //this.ans.push(true);

  }
  // call(){
  //   alert(this.Question.options[0]);
  // }
  setTag() {
    this.cat_touched = true;
    this.Question.tag = "";
    if (this.Question.category == "JAVA") {
      this.tags = this.javaTags;
    }
    else if (this.Question.category == "SQL")
      this.tags = this.sqlTags;
    else if (this.Question.category == "Angular")
      this.tags = this.angularTags;
    else if (this.Question.category == "Other") {
      this.Question.tag = "Other";
    }
    else {
      this.tags = [];
    }
    //this.reg=new RegExp('[0-9]');
    // alert(this.reg.test(this.Question.category));

  }
  tag_touched() {
    this.tagTouched = true;
  }
  incOpt() {
    //alert(this.Question.options[0].desc);

    this.Question.options.push({ desc: "", selected: false });
    //this.ans.push(true);
    //for ( var i=0;i<this.Question.options.length;i++)
    //alert(this.Question.options[i].desc);



  }
  decOpt() {
    let last = this.Question.options.length - 1;
    let index = this.Question.answers.indexOf(last + "");
    console.log('last' + last + 'in' + index);
    if (index != -1)
      this.Question.answers.splice(index, 1);
    this.Question.options.pop();
    //for ( var i=0;i<this.Question.options.length;i++)
    //alert(this.Question.options[i].desc);

  }
  chgchk(event: any) {
    alert(event.target.getAttribute('value'));
    return true;
  }
  clickCk(event: any) {

    //this.ans.map((itemInArray) => itemInArray);
    //alert(this.Question.answers.some(a=>a==event.target.getAttribute('value')));
    if (event.target.getAttribute('value') != "") {
      if ((!this.Question.answers.some(a => a == event.target.getAttribute('value')))) {
        this.Question.answers.push(event.target.getAttribute('value'));

      }

      else {
        let index = this.Question.answers.indexOf(event.target.getAttribute('value'));
        this.Question.answers.splice(index, 1);
      }
    }
    console.log(this.Question.answers);
    //alert(this.Question.answers);
  }
  displayOthers() {
    //alert(this.Question.category);

    if (this.Question.category == "Other") {

      return "block";
    }
    else {
      return "none";
    }
  }
  displaytag() {
    //alert(this.Question.category);
    if (this.Question.tag == "Other" || this.Question.category == "Other") {

      return "block";
    }
    else {
      return "none";
    }
  }
  codisp() {

    if (this.cat_touched == true) {
      if (this.Question.category == "Other" && this.othercat != "") {

        return "block";
      }
      else if (this.Question.category == "Other" && this.othercat == "") {
        return "none";
      }
      else if (this.Question.category != "Select Category") {

        return "block";
      }
      else {


        return "none";

      }



    }
    else {

      return "none";

    }


  }


  cwdisp() {
    //console.log(this.Question.category+"$"+this.othercat+"$");
    if (this.cat_touched == true) {
      if (this.Question.category == "Other" && this.othercat == "") {

        return "block";
      }
      if (this.Question.category == "Other" && this.othercat != "") {

        return "none";
      }
      else if (this.Question.category == "Select Category") {

        return "block";
      } else {

        return "none";
      }
    }
    else {

      return "none";
    }
  }
  todisp() {
    if (this.tagTouched == true) {
      console.log(this.Question.tag);

      if (this.Question.tag == "Other" && this.othertag != "") {

        return "block";
      }
      else if (this.Question.tag == "Other" && this.othertag == "") {
        console.log("tagT1");


        return "none";
      }
      else if (this.Question.tag == "Select Tag") {
        console.log("tagT2");


        return "none";
      }
      else if (this.Question.tag != "Select Tag" && this.Question.tag != "" && this.Question.tag != undefined) {
        console.log("tagT3");


        return "block";
      }
      else {

        return "none";

      }

    }
    else {

      return "none";

    }
  }
  twdisp() {
    // console.log(this.Question.tag+"$"+this.othertag+"$");
    if (this.tagTouched == true) {

      if (this.Question.tag == "Other" && this.othertag == "" || this.Question.tag == undefined) {

        return "block";
      }
      if (this.Question.tag == "Other" && this.othertag != "") {

        return "none";
      }
      else if (this.Question.tag == "Select Tag" || this.Question.tag == "") {

        return "block";
      }
      else {

        return "none";

      }
    }
    else {

      return "none";

    }
  }
  desc_touched() {

    this.descTouched = true;
  }
  d_odisp() {
    if (this.descTouched) {
      console.log(this.Question.quesDesc);

      if (this.Question.quesDesc == "" || this.Question.quesDesc == undefined) {

        return "none";
      }
      else {

        return "block";
      }
    }
    else {

      return "none";
    }

  }
  d_wdisp() {
    if (this.descTouched) {

      if (this.Question.quesDesc == "" || this.Question.quesDesc == undefined) {

        return "block";
      }
      else {

        return "none";
      }
    }
    else {

      return "none";
    }
  }
  aodisp() {
    if (this.Question.answers.length > 0) {

      return "block";
    }
    else {

      return "none";
    }

  }
  awdisp() {

    if (this.Question.answers.length > 0) {

      return "none";
    }
    else {

      return "block";
    }
  }
  dif_touched() {
    this.difTouched = true;
  }
  dodisp() {
    if (this.difTouched) {
      if (this.Question.difficulty != undefined) {

        if (this.Question.difficulty != "Select Difficulty") {

          return "block";
        }
        else {

          return "none";
        }
      }
      else {

        return "none";
      }
    }
    else {

      return "none";
    }

  }
  dwdisp() {
    if (this.difTouched) {
      if (this.Question.difficulty == undefined) {

        return "block";
      }
      if (this.Question.difficulty == "Select Difficulty") {

        return "block";
      }
      else {

        return "none";
      }
    }
    else {

      return "none";
    }
  }
  mark_touched() {
    this.markTouched = true;
  }
  modisp() {
    if (this.markTouched) {
      if (this.Question.mark != undefined && this.Question.mark > 0) {

        return "block";
      }
      else {

        return "none";
      }
    }
    else {

      return "none";
    }

  }
  mwdisp() {
    if (this.markTouched) {
      if (this.Question.mark != undefined && this.Question.mark > 0) {

        return "none";
      }
      else {

        return "block";
      }
    }
    else {

      return "none";
    }
  }


  call() {
    this.cat_touched = true;
    this.tagTouched = true;
    this.descTouched = true;
    this.difTouched = true;
    this.markTouched = true;
    if (this.codisp() == "block" && this.todisp() == "block" && this.d_odisp() == "block" && this.aodisp() == "block" && this.dodisp() == "block" && this.modisp() == "block") {
      this.Question.answers = this.Question.answers.sort();
      console.log(this.Question.answers);
      this.insertQuestion(this.Question).subscribe(result => { console.log(result); this.message = result['metaData']['description']; });
      this.message = "Inserted Successfully..";
    }
    else {
      this.message = "Check fields with 'x' symbol..";
    }

  }
  insertQuestion(question: Question): Observable<any> {
    if (question.category == "Other") {
      this.category = this.othercat;
    }
    else {
      this.category = question.category;
    }
    if (question.tag == "Other" || question.category == "Other") {
      this.tag = this.othertag;
    }
    else {
      this.tag = question.tag;
    }

    //let optionString="[";
    let i;
    for (i = 0; i < question.options.length; i++) {
      this.options.push(question.options[i].desc);
    }
    //optionString+=question.options[question.options.length-1].desc+"]";
    //console.log(optionString);


    this.time = new Date();
    let latest_date = this.datepipe.transform(this.time, 'yyyy-MM-ddTHH:mm');
    this.Question.quesId = "q" + localStorage.getItem("currentUser");
    question.quesId += latest_date;
    console.log(question.quesId);
    //localStorage.getItem('commitId')   
    let insert = { "commitId": localStorage.getItem("currentUser"), "category": this.category, "tag": this.tag, "questions": [{ quesId: question.quesId, quesDesc: question.quesDesc, options: this.options, "answers": this.Question.answers, "difficulty": question.difficulty, "mark": question.mark, "image": localStorage.getItem("image") }], "status": question.status };
    console.log(insert);
    return this.http.post('http://172.24.34.250:8080/QuizApp/library', insert).map(response => response.json);
  }
  navigateLibrary(){
    this.router.navigate(['nav/sideLibrary']);
  }
  
}

