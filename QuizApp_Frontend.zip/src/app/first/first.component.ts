import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
 
  clicked : true;
  constructor(private router : Router) { }

  ngOnInit() {
  }

  createTest(){
    this.router.navigate(['/nav/sideLibrary']);
  }
  takeTest(){
    this.router.navigate(['/listtest']);
  }
}
