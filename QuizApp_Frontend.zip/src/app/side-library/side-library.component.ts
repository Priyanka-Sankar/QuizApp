import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { AllQuestionsComponent } from '../all-questions/all-questions.component';
import 'assets/js/sidetab.js';

@Component({
  selector: 'app-side-library',
  templateUrl: './side-library.component.html',
  styleUrls: ['./side-library.component.css']
})
export class SideLibraryComponent implements OnInit {
  @ViewChild('myQues') child: AllQuestionsComponent;

  constructor(private router: Router) { }
  ngOnInit() {
  }
  ngAfterViewInit() {

  }
  refresh() {
    this.child.ngOnInit();
  }

}
