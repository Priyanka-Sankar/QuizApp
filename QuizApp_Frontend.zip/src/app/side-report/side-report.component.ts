import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminReportComponent } from '../admin-report/admin-report.component';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-side-report',
  templateUrl: './side-report.component.html',
  styleUrls: ['./side-report.component.css']
})
export class SideReportComponent implements OnInit {

  @ViewChild('myRep') child: AdminReportComponent;

  constructor(private router: Router) { }
  ngOnInit() {
  }
  ngAfterViewInit() {

  }
  refresh() {
    this.child.ngOnInit();
  }

}
