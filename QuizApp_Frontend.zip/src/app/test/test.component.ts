import { Component, ViewContainerRef, OnInit } from '@angular/core';
import { Test } from '../_models/tests';
import { Router } from '@angular/router';
import { TestService } from '../_services/test.service';
import { TestStorageService } from '../_services/test-storage.service';
import { MinuteToHour } from '../_filters/min-to-hour';
import { Question } from '../_models/question';
import 'assets/js/sidetab.js';
import 'assets/js/add-options.js';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  testBean: Test[];
  filteredTest : Test[];
  testToEdit: Test = new Test();
  toDelete: string;
  show : boolean;
  showQues : boolean;
  showFilter : boolean;
  noData : boolean;
  flag = new Boolean()[9];
  success: boolean[];
  inputText: string
  testShowDialog = false;
  editShowDialog = false;
  delShowDialog = false;
  message : string;
  newTest : Test = new Test();
  questions : Question[];
  testToDelQues:string;

  constructor(private router: Router, private testService: TestService, private storageService : TestStorageService) {
    this.flag = [];
    this.filteredTest = [];
    
    for (let i = 0; i < 7; i++)
      this.flag[i] = false;
    this.success = [];
    for (let i = 0; i < 7; i++)
      this.success[i] = false;
  }

  ngOnInit() {
    console.log('ngoninitttttt');
    this.show = false;
    this.showQues = false;
    this.showFilter = false;
    this.noData = false;
    this.inputText = '';
    

    //localStorage.getItem('currentUser')
    this.testService.getByCommitId(localStorage.getItem('currentUser')).
      subscribe(data => {
        this.testBean = data['data']['output'];
        if(this.testBean.length == 0){
        this.noData = true;
        this.show = false;
        this.showQues = false;
      }
      else{
        this.show = true;
        this.noData = false;
        this.showQues = false;
      }
      });
      
  }

  onDelete(testId: string) {
    this.toDelete = testId;
    this.delShowDialog = true;
  }

  delete() {

    console.log(this.toDelete);
    this.delShowDialog = false;
    this.testService.deleteByTestId(this.toDelete).
      subscribe(data => {

           this.ngOnInit();
        
      },
      error => {
      
        this.ngOnInit();
      })
this.message = 'Deleted Successfully';
  }
  onEdit(testId: string) {
    this.editShowDialog = true;
    for (let i = 0; i < this.testBean.length; i++) {
      if (this.testBean[i].testId == testId) {
        this.testToEdit = this.testBean[i];
      }
    }
  }
  setFlag(num: any) {
    console.log(num);
    this.flag[num] = new Boolean();
    this.flag[num] = true;
  }
  onSubmit() {
    console.log("onsubmut");


    if (this.flag[0]) {
      this.testService.editTestName(this.testToEdit).
        subscribe(data => {

          alert(data['metaData']['description']);
        });
    }
    if (this.flag[1])
      this.testService.editTestDuration(this.testToEdit).
        subscribe(data => {
          alert(data['metaData']['description']);
        });
    if (this.flag[2])
      this.testService.editTestCutoff(this.testToEdit).
        subscribe(data => {
          alert(data['metaData']['description']);
        });
    if (this.flag[3]) {
      console.log("endtime");
      this.testService.editEndTime(this.testToEdit).
        subscribe(data => {
          alert(data['metaData']['description']);
        });
    }
    if (this.flag[4]) {
      console.log("starttime");
      this.testService.editStartTime(this.testToEdit).
        subscribe(data => {
          alert(data['metaData']['description']);
        });
    }
    if (this.flag[5])
      this.testService.editTestShowMark(this.testToEdit).
        subscribe(data => {
          alert(data['metaData']['description']);
        });
    if (this.flag[6])
      this.testService.editTestShuffle(this.testToEdit).
        subscribe(data => {
          alert(data['metaData']['description']);
        });
    this.editShowDialog = false;
    this.ngOnInit();
  }

  filterOnSearch() {
    this.show = false;
    this.noData = false;
    this.showQues = false;
    this.filteredTest = [];
    for(let i = 0;i<this.testBean.length;i++)
      {
        if(this.testBean[i].testName.toLowerCase().indexOf(this.inputText.toLowerCase()) != -1)
          this.filteredTest.push(this.testBean[i]);
      }
      this.showFilter = true;
      if(this.filteredTest.length == 0)
        {
          this.noData = true;
          this.show = false;
          this.showFilter = false;
          this.showQues = false;
        }
  }
    
  createTest(){
let regexp = new RegExp('^[\\w\\-\\s]+$');      
if(!regexp.test(this.newTest.testName)){
  alert('Test name sholud not contain any special characters');
  return false;
}
if(this.newTest.startTime == undefined) {
  alert('Invalid startTime');    
  return false;
}
if(this.newTest.expiryTime == undefined){
  alert('Invalid endtime');
  return false;
}
if(!this.newTest.showMark){
  this.newTest.showMark = false;
}

this.router.navigate(['nav/sideLibrary/allquestions']);
}

callQuesDisplay(testId : string){
  this.showQues = true;
  this.show = false;
  this.noData = false;
  this.showFilter = false;
  this.questions = [];
  this.testToDelQues = testId;
  for(let i=0;i<this.testBean.length;i++){
    if(this.testBean[i]['testId'] == testId){
      for(let j=0;j<this.testBean[i].questions.length;j++)
      this.questions.push(this.testBean[i].questions[j]);
      break;
    }
  }
  console.log(this.questions);
}
checkAns(answers: any[], index: number) {
    if (answers.indexOf(index) >= 0)
      return true;
    return false;
  }
   preventEdit() {
    return false;
  }
   delQues(quesId:string){
    this.testService.removeQuesFromTest(this.testToDelQues,quesId).subscribe(data=>{
      alert('Question removed');
      this.router.navigate(['nav/side']);
    });
  }
  navigateLibrary(){
    this.router.navigate(['nav/sideLibrary']);
  }
}
