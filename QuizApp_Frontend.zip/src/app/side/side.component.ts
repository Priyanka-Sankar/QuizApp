import { Component, OnInit,ViewChild } from '@angular/core';
import { Router,RouterModule } from '@angular/router';
import { TestComponent } from '../test/test.component';

import 'assets/js/sidetab.js';
@Component({
  selector: 'app-side',
  templateUrl: './side.component.html',
  styleUrls: ['./side.component.css'],
      

})
export class SideComponent implements OnInit {
  @ViewChild('myTest') child: TestComponent;
  constructor(private router : Router) { 
    
  }

  ngOnInit() {
  }
  ngAfterViewInit() {
    
}
  refresh(){
   this.child.ngOnInit();
  }
}
