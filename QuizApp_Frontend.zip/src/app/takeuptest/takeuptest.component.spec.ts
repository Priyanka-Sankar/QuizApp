import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeuptestComponent } from './takeuptest.component';

describe('TakeuptestComponent', () => {
  let component: TakeuptestComponent;
  let fixture: ComponentFixture<TakeuptestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeuptestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeuptestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
