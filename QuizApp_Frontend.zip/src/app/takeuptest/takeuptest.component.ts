import { Component, OnInit } from '@angular/core';

import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import {Question} from './Question';
import {TestReport} from '../_models/test-report';
import { PagerService } from '../_services/index';
import * as _ from 'underscore';
 import{ TestService } from '../_services/test.service';
 import { ReportService} from '../_services/report.service';
import {TimerComponent} from '../timer/timer.component';
import { QuestionReport} from '../_models/question-report';

import { Router } from '@angular/router';
//Timer 
import { Subscription } from 'rxjs/Rx';
 import { ActivatedRoute } from '@angular/router';
import 'assets/js/modal-jquery.js';


@Component({
  selector: 'app-takeuptest',
  templateUrl: './takeuptest.component.html',
  styleUrls: ['./takeuptest.component.css']
})

export class TakeuptestComponent implements OnInit {

   qReports:QuestionReport[]=[];
   tReport:TestReport=new TestReport();
   testId:string;
   constructor(private http: Http, private pagerService: PagerService,private testService:TestService,private route: ActivatedRoute,private rservice: ReportService,private router:Router) { }

  // Timer Component
  //tickss :number=0;
    
    minutesDisplay: number = 0;
    hoursDisplay: number = 0;
    secondsDisplay: number = 0;

    sub: Subscription;



   //private allItems: any[];
   pager: any = {};
    
   Qbean:Question[];
   private allItems:any[];
   
   Questions:any[];
  
   FQuestions:Question[]=[];
    pagedItems: any;
    ticks:number=0;
    ltime:string[];
    lttime:string;
    hours:string;
    minutes:string;
    seconds:string;
    temp1:number;
     temp:any[];
    showMark : boolean;
    shuffleOpt:boolean;
    submit:boolean;
    testname:string;
    testnameCheck:boolean;
    id:string;
    private subs:any;
    score:number;
  ngOnInit() {



    this.subs = this.route.params.subscribe(params => {
       this.id = params['id']; // (+) converts string 'id' to a number

       // In a real app: dispatch action to load the details here.
    });
  
    this.testService.getQuestionByTestId(this.id).
      subscribe(data=>{
        this.allItems=data['data']['output'];
       
         this.Questions=data['data']['output'][0]['questions'];
      
         this.testId=data['data']['output'][0]['testId'];
         this.showMark = ((data['data']['output'][0]['showMark'])=="true") ? true : false;
       
                this.shuffleOpt=data['data']['output'][0]['shuffle'];
        this.testname=data['data']['output'][0]['testName'];
        
    
        //if(this.testname.length>0)
            //this.testnameCheck=true;

        //Checking Shuffle Options
          if(this.shuffleOpt==true)
            this.Questions=this.shuffle(this.Questions);
         
            //console.log("q0"+this.Questions1);
          

        let i:number;
        let temp;
        
        let options:string[];
        for(i=0;i<this.Questions.length;i++)
         {
           this.FQuestions[i]=new Question();
           this.FQuestions[i].quesId=this.Questions[i]['quesId'];
           this.FQuestions[i].quesDesc=this.Questions[i]['quesDesc'];
           this.FQuestions[i].answers=this.Questions[i]['answers'];
           this.FQuestions[i].mark=this.Questions[i]['mark'];
           this.FQuestions[i].difficulty=this.Questions[i]['difficulty'];
           this.FQuestions[i].image=this.Questions[i]['image'];
           options=this.Questions[i]['options'];
            this.FQuestions[i].options=[];
           for(let j=0;j<options.length;j++)
            {
            
              this.FQuestions[i].options.push({desc:options[j],selected:false});
            }


        //console.log(options);
         }

       if(!localStorage.getItem('ticks')){
        
    this.ticks=this.allItems[0]['duration'];
          this.ticks*=60;
        
       }
      else{
        this.ticks =parseInt(localStorage.getItem('ticks'));
      }
      
        this.setPage(1);
       this.setTicks(this.ticks);
      
      });


   
  }
     i:number=1;
  setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
          //alert('hello');
            return;
        }
// alert(this.allItems.length);
        // get pager object from service
        this.pager = this.pagerService.getPager(this.FQuestions.length, page);
        //alert(this.Questions.length);
        // get current page of items
        this.pagedItems = this.FQuestions.slice(this.pager.startIndex, this.pager.endIndex + 1);
        //alert(this.pager.endIndex);
        if(this.pager.currentPage==this.FQuestions.length)
          {
                this.submit=true;
          }
              else
                this.submit=false;
}
      chkimage(image:string)
      {
        if(image==null)
          {
            return "none";
          }
          else
            return "block";
      }


 setTicks(tick:number)
  {
    this.ticks=tick;
    this.startTimer();
  }

  private startTimer() {

        let timer = Observable.timer(1, 1000);
        this.sub = timer.subscribe(
            t => {
                if(this.ticks!=0)
                this.ticks -= 1;
               
                this.secondsDisplay = this.getSeconds(this.ticks);
                this.minutesDisplay = this.getMinutes(this.ticks);
                this.hoursDisplay = this.getHours(this.ticks);
                localStorage.setItem('ticks',''+this.ticks);
               // console.log("Set Duration is"+this.ticks);
               // console.log(this.hours+this.minutes+this.seconds);
               if(this.ticks==0)
                this.finishTest();
            }
        );
    }


    private getSeconds(ticks: number) {
        return this.pad(ticks % 60);
    }

    private getMinutes(ticks: number) {
         return this.pad((Math.floor(ticks / 60)) % 60);
    }

    private getHours(ticks: number) {
        // if(ticks==0)
        //     return 0;
        // else
            return this.pad(Math.floor((ticks / 60) / 60));
    }

    private pad(digit: any) { 
        return digit <= 9 ? '0' + digit : digit;
    }

public stopTimer()
{
  this.sub.unsubscribe();
}
finishTest()
{
  alert('TEST OVER');
  this.stopTimer();
 
  localStorage.removeItem('ticks');
 
  this.calResult();



  // if(this.ticks == 0)
  //   window.close();
 this.ticks=0;
//this.router.navigate(['/']);
}
calResult()
{
  let QFinal=this.FQuestions;
let score=0;

let noOfCorrect=0;
  for(let i=0;i<QFinal.length;i++)
    {
      this.qReports[i]=new QuestionReport();
      this.qReports[i].quesId=QFinal[i].quesId;
      this.qReports[i].commitId=localStorage.getItem('currentUser');
      this.qReports[i].testId=this.testId;
     
      let answer=[];
      for(let j=0;j<QFinal[i].options.length;j++)
        {

          if(QFinal[i].options[j].selected)
            {
              answer.push(j+"");
            }
        }
          answer=answer.sort();
          let f=0;
           this.qReports[i].chosenAns=answer;
           this.rservice.insertQuesReport(this.qReports[i]).subscribe(data=>{});


          if(answer.length==this.FQuestions[i].answers.length)
            {
          for(let k=0;k<answer.length;k++)
            {
              if(this.FQuestions[i].answers[k]!=answer[k])
              {        f=1;
                break;
              }

            }
            if(f==0)
              {
                score+=this.FQuestions[i].mark;
                noOfCorrect+=1;
              }
              f=0;
            }
          else{
            score+=0;
          }

          this.score=score;
          }
        //this.tReport.commitId=localStorage.getItem('commitId');
        this.tReport.commitId=localStorage.getItem('currentUser');
        this.tReport.noOfCorrect=noOfCorrect;
        this.tReport.testId=this.testId;
        this.tReport.totalScore=this.score;
        this.rservice.insertTestReport(this.tReport).subscribe(data=>{});
    //  let priceListMap : Map<number, Product[]> = new Map<number, Product[]>();
          let tmap : Map<string, string> = new Map<string, string>();
          tmap.set(this.tReport.testId, new Date().toString());
          let bean ={commitId:this.tReport.commitId,tests:tmap};

          // this.testService.insertAtest(bean).subscribe(data=>{
          //   alert('Inside atest');
          // });
    }
       


      // Shuffling
      shuffle(temp1:any[]) {
    //temp:any[];
     
    for (var i = temp1.length-1; i >=0; i--) {
     
        var randomIndex = Math.floor(Math.random()*(i+1)); 
        var itemAtIndex = temp1[randomIndex]; 
         
        temp1[randomIndex] =temp1[i]; 
        temp1[i] = itemAtIndex;
    }
    return temp1;
}
arr:any[];
checked(option,event)
{

  //console.log("HELLO");
// if ((<HTMLInputElement>document.getElementById(value)).checked === true) {
//             this.arr.push(value);
//         }
//         else if ((<HTMLInputElement>document.getElementById(value)).checked === false) {
//             let indexx = this.arr.indexOf(value);
//             this.arr.splice(indexx,1)
//         }

// console.log(this.arr);
}

closeWindow(){
  window.close();
}
 ngOnDestroy() {
    this.subs.unsubscribe();
  }

  }