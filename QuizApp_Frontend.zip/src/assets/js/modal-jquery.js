$(document).on('click', '#fTest', function (e) {
console.log('this is the click');

$("#myModal").appendTo("body").modal('show');
e.preventDefault();
});
