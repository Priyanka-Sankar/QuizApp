 
// Load google charts
window.onload=function call(){
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
 

} // Draw the chart and set the chart values
function drawChart() {
    //alert('call');
   var a=localStorage.getItem('catScore').split(',');
 
 var array=new Array(a.length/2);
 for(var i=0;i<a.length/2;i++)
    {
        array[i]=new Array(2);
    }
 var k=0;
 for(var i=0;i<a.length/2;i++)
    {
        for(var j=0;j<2;j++)
            {

                if(i!=0 && j==1)
                    {
                array[i][j]=parseInt(a[k]);
                                    }
            else{
                 array[i][j]=a[k];
            }
                            k=k+1;
            }
    }

    
   var data = google.visualization.arrayToDataTable(array);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Category vs your score', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.BarChart(document.getElementById('piechart'));
  chart.draw(data, options);

  
   var a1=localStorage.getItem('tScore').split(',');
// alert(a1);
 var array1=new Array(a1.length/2);
 for(var i=0;i<a1.length;i++)
    {
        array1[i]=new Array(2);
    }
 var k1=0;
 for(var i=0;i<a1.length/2;i++)
    {
        for(var j=0;j<2;j++)
            {

                if(i!=0 && j==1)
                    {
                array1[i][j]=parseInt(a1[k1]);
                                    }
            else{
                 array1[i][j]=a1[k1];
            }
                            k1=k1+1;
            }
    }
       // alert(array1);

    
   var data1 = google.visualization.arrayToDataTable(array1);

  // Optional; add a title and set the width and height of the chart
  var options1 = {'title':'CommitId vs Score', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart1 = new google.visualization.BarChart(document.getElementById('chart'));
  chart1.draw(data1, options1);
}
