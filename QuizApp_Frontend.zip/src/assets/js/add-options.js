$(document).on('click', '#myBtn', function (e) {
    $("#myModal").appendTo("body").modal('show');
    e.preventDefault();
})
    .on('click', '#myBtn1', function (e) {

        $("#myModal1").appendTo("body").modal('show');
        e.preventDefault();
    })
    .on('click', '#edit', function (e) {

        $("#myModal2").appendTo("body").modal('show');
        e.preventDefault();
    })
    
    .on('click', '#addToTest', function (e) {
        $("#addTestModal").appendTo("body").modal('show');


        e.preventDefault();
    })
    ;


function previewFile() {

    var file = document.querySelector('input[type=file]').files[0];

    var reader = new FileReader();

    reader.addEventListener("load", function () {


        localStorage.setItem("image", reader.result);
        alert(reader.result);

    }, false);

    if (file) {

        reader.readAsDataURL(file);

    }
}


